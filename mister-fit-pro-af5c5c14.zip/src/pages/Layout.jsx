

import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  LayoutDashboard, Users, Dumbbell, Menu, UserCircle, ClipboardList, Salad,
  ClipboardCheck, MessageSquare, Landmark, Sparkles, Settings, LogOut, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { User } from '@/api/entities';

const trainerNavigation = [
  { title: 'Dashboard', url: createPageUrl('dashboard'), icon: LayoutDashboard },
  { title: 'Alunos', url: createPageUrl('Students'), icon: Users },
  { title: 'Criar Treinos', url: createPageUrl('Workouts'), icon: ClipboardList },
  { title: 'Criar Dietas', url: createPageUrl('Diets'), icon: Salad },
  { title: 'Chat', url: createPageUrl('Chat'), icon: MessageSquare },
  { title: 'Financeiro', url: createPageUrl('Financial'), icon: Landmark },
  { title: 'Sugestão IA', url: createPageUrl('AI'), icon: Sparkles },
];

const studentNavigation = [
    { title: 'Meu Painel', url: createPageUrl('StudentDashboard'), icon: LayoutDashboard },
    { title: 'Meu Treino', url: createPageUrl('StudentWorkout'), icon: Dumbbell },
    { title: 'Minha Dieta', url: createPageUrl('StudentDiet'), icon: Salad },
    { title: 'Minhas Avaliações', url: createPageUrl('StudentAssessments'), icon: ClipboardCheck },
    { title: 'Chat', url: createPageUrl('Chat'), icon: MessageSquare },
];

// Navegação para Admin (igual ao trainer por agora)
const adminNavigation = [
  { title: 'Dashboard', url: createPageUrl('dashboard'), icon: LayoutDashboard },
  { title: 'Usuários', url: createPageUrl('Users'), icon: Users }, // Changed to 'Users' page for admin, assuming it exists or will exist
  { title: 'Treinos', url: createPageUrl('Workouts'), icon: ClipboardList },
  { title: 'Dietas', url: createPageUrl('Diets'), icon: Salad },
  { title: 'Chat', url: createPageUrl('Chat'), icon: MessageSquare },
  { title: 'Financeiro', url: createPageUrl('Financial'), icon: Landmark },
  { title: 'IA', url: createPageUrl('AI'), icon: Sparkles },
];

const bottomNavigation = [
    { title: 'Meu Perfil', url: createPageUrl('Profile'), icon: UserCircle },
    { title: 'Configurações', url: createPageUrl('Settings'), icon: Settings },
];

const AppLogo = ({ userRole }) => (
  <Link to={createPageUrl(userRole === 'student' ? 'StudentDashboard' : 'dashboard')} className="flex items-center gap-3">
    <img 
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ee7cadce2_novologo.png" 
      alt="MisterFit Logo" 
      className="w-10 h-10 object-contain"
    />
    <h1 className="text-xl font-bold text-gray-800">MisterFit</h1>
  </Link>
);

const NavLinks = ({ items, className }) => {
  const location = useLocation();
  return (
    <nav className={`flex flex-col gap-1 ${className}`}>
      {items.map((item) => (
        <Link key={item.title} to={item.url}>
          <Button
            variant={location.pathname === item.url ? 'secondary' : 'ghost'}
            className="w-full justify-start gap-3"
          >
            <item.icon className="w-4 h-4" />
            {item.title}
          </Button>
        </Link>
      ))}
    </nav>
  );
};

export default function Layout({ children, currentPageName }) {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const location = useLocation();

    useEffect(() => {
        const checkAuth = async () => {
            // A plataforma redirecionará para /login se não houver usuário.
            // Nossa lógica só precisa lidar com usuários LOGADOS.
            try {
                const currentUser = await User.me();
                setUser(currentUser);

                // Se o usuário foi criado há menos de 60s, é um novo usuário
                const userCreatedTime = new Date(currentUser.created_date).getTime();
                const now = new Date().getTime();
                const timeDifferenceInSeconds = (now - userCreatedTime) / 1000;
                
                if (timeDifferenceInSeconds < 60 && currentPageName !== 'CompleteProfile') {
                    window.location.href = createPageUrl('CompleteProfile');
                    return;
                }

                // Se não tem role, também deve completar o perfil
                if (!currentUser.role) {
                    if (currentPageName !== 'CompleteProfile') {
                        window.location.href = createPageUrl('CompleteProfile');
                    }
                    return; 
                }

                // Se já tem role e está na página de cadastro, redireciona para o dashboard
                if (currentUser.role && currentPageName === 'CompleteProfile') {
                    const dashboardUrl = currentUser.role === 'student' ? createPageUrl('StudentDashboard') : createPageUrl('dashboard');
                    window.location.href = dashboardUrl;
                    return;
                }
                
                // Validações de acesso de página (sem alterações)
                const studentPages = ['StudentDashboard', 'StudentWorkout', 'StudentDiet', 'StudentAssessments'];
                const trainerAdminPages = ['dashboard', 'Students', 'Workouts', 'Diets', 'Financial', 'AI', 'Users'];
                
                if (currentUser.role === 'student' && trainerAdminPages.includes(currentPageName)) {
                    window.location.href = createPageUrl('StudentDashboard');
                } else if ((currentUser.role === 'trainer' || currentUser.role === 'admin') && studentPages.includes(currentPageName)) {
                    window.location.href = createPageUrl('dashboard');
                }
                
            } catch (error) {
                // Erro significa que não está logado.
                // A plataforma base44 deve forçar o /login automaticamente.
                // Não precisamos fazer nada aqui.
                console.log('❌ [Layout] Nenhum usuário logado. A plataforma deve redirecionar para /login.');
                setUser(null);
            } finally {
                setIsLoading(false);
            }
        };

        checkAuth();
    }, [currentPageName, location.pathname]);

    const handleLogout = async () => {
        try {
            // Tentar logout via User.logout()
            await User.logout();
        } catch (error) {
            console.log('Erro no logout padrão, forçando limpeza manual:', error);
        }
        
        // Forçar limpeza manual de dados locais
        try {
            localStorage.clear();
            sessionStorage.clear();
        } catch (e) {
            console.log('Erro ao limpar storage:', e);
        }
        
        // Redirecionar para landing forçando reload
        window.location.href = createPageUrl('Landing'); // This will redirect to the root which will then be handled by the platform as a non-logged in user
        window.location.reload();
    };
    
    // Página que não usa a sidebar/header
    const standalonePages = ['CompleteProfile'];
    
    // Mostra um loader global enquanto a verificação acontece
    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <Loader2 className="w-12 h-12 text-orange-500 animate-spin mx-auto mb-4" />
                    <p className="text-gray-500">Carregando...</p>
                </div>
            </div>
        );
    }
    
    if (standalonePages.includes(currentPageName)) {
        return <>{children}</>;
    }
    
    // Não renderiza nada enquanto o redirecionamento para /login acontece
    if (!user) {
        return null; 
    }

    const mainNav = user.role === 'student' ? studentNavigation : 
                   user.role === 'admin' ? adminNavigation : 
                   trainerNavigation;
    
    const mobileBottomNav = (user.role === 'student') 
        ? [
            { title: 'Painel', url: createPageUrl('StudentDashboard'), icon: LayoutDashboard },
            { title: 'Treino', url: createPageUrl('StudentWorkout'), icon: Dumbbell },
            { title: 'Chat', url: createPageUrl('Chat'), icon: MessageSquare },
            { title: 'Perfil', url: createPageUrl('Profile'), icon: UserCircle },
          ]
        : [
            { title: 'Dashboard', url: createPageUrl('dashboard'), icon: LayoutDashboard },
            { title: user.role === 'admin' ? 'Usuários' : 'Alunos', url: createPageUrl(user.role === 'admin' ? 'Users' : 'Students'), icon: Users }, // Adjusted URL for admin
            { title: 'Chat', url: createPageUrl('Chat'), icon: MessageSquare },
            { title: 'Perfil', url: createPageUrl('Profile'), icon: UserCircle },
          ];

  return (
    <div className="min-h-screen w-full bg-[#F0F5FA] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-white p-4">
        <AppLogo userRole={user.role} />
        <NavLinks items={mainNav} className="mt-8" />
        <div className="mt-auto flex flex-col gap-1">
          <NavLinks items={bottomNavigation} />
           <Button variant="ghost" className="w-full justify-start gap-3" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          {user && (
            <div className="flex items-center gap-3 p-2 rounded-lg bg-gray-100 mt-4 border">
                <div className="w-8 h-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                    {user.full_name?.[0]?.toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{user.full_name}</p>
                    <p className="text-xs text-gray-500 capitalize">
                        {user.role === 'admin' ? 'Administrador' : 
                         user.role === 'trainer' ? 'Personal Trainer' : 
                         'Aluno'}
                    </p>
                </div>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b bg-white sticky top-0 z-40">
          <AppLogo userRole={user.role} />
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 p-4 flex flex-col">
               <AppLogo userRole={user.role} />
               <NavLinks items={mainNav} className="mt-8" />
               <div className="mt-auto flex flex-col gap-1">
                  <NavLinks items={bottomNavigation} />
                   <Button variant="ghost" className="w-full justify-start gap-3" onClick={handleLogout}>
                      <LogOut className="w-4 h-4" />
                      Sair
                    </Button>
               </div>
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto pb-24 md:pb-8">
            {children}
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <footer className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-50">
            <div className="flex justify-around items-center h-16">
                {mobileBottomNav.map((item) => (
                    <Link 
                        key={item.title} 
                        to={item.url} 
                        className={`flex flex-col items-center justify-center text-xs w-full h-full transition-colors ${
                            location.pathname === item.url ? 'text-orange-600' : 'text-gray-500 hover:bg-gray-100'
                        }`}
                    >
                        <item.icon className="w-5 h-5 mb-1" />
                        <span>{item.title}</span>
                    </Link>
                ))}
            </div>
        </footer>
      </div>
    </div>
  );
}


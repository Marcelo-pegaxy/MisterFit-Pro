import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Students from "./Students";

import Exercises from "./Exercises";

import Profile from "./Profile";

import Workouts from "./Workouts";

import Diets from "./Diets";

import Chat from "./Chat";

import Financial from "./Financial";

import AI from "./AI";

import Settings from "./Settings";

import dashboard from "./dashboard";

import StudentDashboard from "./StudentDashboard";

import StudentWorkout from "./StudentWorkout";

import StudentDiet from "./StudentDiet";

import StudentAssessments from "./StudentAssessments";

import CompleteProfile from "./CompleteProfile";

import TestUsers from "./TestUsers";

import StudentDetails from "./StudentDetails";

import Landing from "./Landing";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Students: Students,
    
    Exercises: Exercises,
    
    Profile: Profile,
    
    Workouts: Workouts,
    
    Diets: Diets,
    
    Chat: Chat,
    
    Financial: Financial,
    
    AI: AI,
    
    Settings: Settings,
    
    dashboard: dashboard,
    
    StudentDashboard: StudentDashboard,
    
    StudentWorkout: StudentWorkout,
    
    StudentDiet: StudentDiet,
    
    StudentAssessments: StudentAssessments,
    
    CompleteProfile: CompleteProfile,
    
    TestUsers: TestUsers,
    
    StudentDetails: StudentDetails,
    
    Landing: Landing,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Students" element={<Students />} />
                
                <Route path="/Exercises" element={<Exercises />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Workouts" element={<Workouts />} />
                
                <Route path="/Diets" element={<Diets />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/Financial" element={<Financial />} />
                
                <Route path="/AI" element={<AI />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/dashboard" element={<dashboard />} />
                
                <Route path="/StudentDashboard" element={<StudentDashboard />} />
                
                <Route path="/StudentWorkout" element={<StudentWorkout />} />
                
                <Route path="/StudentDiet" element={<StudentDiet />} />
                
                <Route path="/StudentAssessments" element={<StudentAssessments />} />
                
                <Route path="/CompleteProfile" element={<CompleteProfile />} />
                
                <Route path="/TestUsers" element={<TestUsers />} />
                
                <Route path="/StudentDetails" element={<StudentDetails />} />
                
                <Route path="/Landing" element={<Landing />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}

import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { WorkoutPlan } from '@/api/entities';
import { DietPlan } from '@/api/entities';
import { RecentActivity } from '@/api/entities';
import { Payment } from '@/api/entities';
import { UserAccount } from '@/api/entities/UserAccount';
import { Assessment } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Users, ClipboardList, Salad, TrendingUp, AlertTriangle, History, PlusCircle, LinkIcon } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const StatCard = ({ title, value, subtext, icon: Icon, isLoading, link, action, variant }) => (
  <Card className={`bg-white shadow-sm hover:shadow-md transition-shadow ${variant === 'highlight' ? 'ring-2 ring-orange-200' : ''}`}>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
      <Icon className="h-5 w-5 text-gray-400" />
    </CardHeader>
    <CardContent>
      {isLoading ? (
        <Skeleton className="h-8 w-1/2 mt-2" />
      ) : (
        <>
          <div className="text-2xl font-bold text-gray-800">{value}</div>
          <p className="text-xs text-gray-500">{subtext}</p>
          {(link || action) && (
            <div className="mt-3">
              {link ? (
                <Link to={link}>
                  <Button size="sm" variant="outline" className="text-xs">
                    Ver Todos
                  </Button>
                </Link>
              ) : (
                <Button size="sm" variant="outline" className="text-xs" onClick={action}>
                  Adicionar
                </Button>
              )}
            </div>
          )}
        </>
      )}
    </CardContent>
  </Card>
);

const AttentionPayments = ({ payments, students, isLoading }) => (
    <Card className="bg-white shadow-sm">
        <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
                <AlertTriangle className="w-5 h-5 text-yellow-500" />
                Atenção Pagamentos
            </CardTitle>
        </CardHeader>
        <CardContent>
            {isLoading ? <Skeleton className="h-4 w-full" /> :
             payments.length > 0 ? (
                <div className="space-y-2 max-h-32 overflow-y-auto">
                    {payments.map(p => {
                        const student = students.find(s => s.email === p.student_email);
                        return (
                            <div key={p.id} className="text-sm p-2 bg-yellow-50 rounded border-l-4 border-yellow-400">
                                <span className="font-medium">{student?.full_name || p.student_email}</span>
                                <br />
                                <span className="text-gray-600">Status: </span>
                                <Badge className={p.status === 'atrasado' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}>
                                    {p.status}
                                </Badge>
                                {p.due_date && (
                                    <span className="text-xs text-gray-500 block">
                                        Vencimento: {new Date(p.due_date).toLocaleDateString('pt-BR')}
                                    </span>
                                )}
                            </div>
                        );
                    })}
                </div>
             ) : (
                <p className="text-sm text-gray-500">✅ Todos os pagamentos estão em dia!</p>
             )
            }
        </CardContent>
    </Card>
);

const RecentActivities = ({ activities, isLoading }) => (
    <Card className="bg-white shadow-sm">
        <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
                <History className="w-5 h-5 text-gray-500" />
                Atividades Recentes
            </CardTitle>
        </CardHeader>
        <CardContent>
            <div className="space-y-3 max-h-32 overflow-y-auto">
            {isLoading ? Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-8 w-full" />) :
             activities.length > 0 ? (
                activities.map(act => (
                    <div key={act.id} className="flex justify-between items-start text-sm p-2 hover:bg-gray-50 rounded">
                        <p className="text-gray-700 flex-1">{act.description}</p>
                        <p className="text-gray-500 text-xs flex-shrink-0 ml-4">
                            {formatDistanceToNow(new Date(act.created_date), { addSuffix: true, locale: ptBR })}
                        </p>
                    </div>
                ))
             ) : (
                <p className="text-sm text-gray-500">Nenhuma atividade recente.</p>
             )
            }
            </div>
        </CardContent>
    </Card>
);

const LinkStudentForm = ({ trainer, onStudentLinked }) => {
    const [shareId, setShareId] = useState('');
    const [isLinking, setIsLinking] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLinking(true);
        setError('');
        setSuccess('');

        if (!shareId.trim()) {
            setError("Por favor, insira o ID do aluno.");
            setIsLinking(false);
            return;
        }

        try {
            const allUsers = await UserAccount.list();
            const studentsToLink = allUsers.filter(user => 
                user.unique_share_id === shareId.trim().toUpperCase() && 
                user.role === 'student'
            );
            
            if (studentsToLink.length === 0) {
                setError(`Nenhum aluno encontrado com este ID.`);
                setIsLinking(false);
                return;
            }

            const student = studentsToLink[0];

            if (student.linked_trainer_email) {
                setError(`Este aluno já está vinculado a ${student.linked_trainer_email === trainer.email ? 'você' : 'outro personal'}.`);
                setIsLinking(false);
                return;
            }

            await UserAccount.update(student.id, { linked_trainer_email: trainer.email });
            
            // Registrar atividade
            await RecentActivity.create({
                trainer_email: trainer.email,
                description: `Novo aluno vinculado: ${student.full_name}`,
                link_to: createPageUrl(`StudentDetails?id=${student.id}`)
            });
            
            setSuccess(`Aluno ${student.full_name} vinculado com sucesso!`);
            setShareId('');
            setTimeout(() => {
                onStudentLinked();
            }, 1500);

        } catch (err) {
            console.error("Erro ao vincular aluno:", err);
            setError("Ocorreu um erro inesperado. Tente novamente.");
        } finally {
            setIsLinking(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div>
                <Label htmlFor="shareId">ID de Compartilhamento do Aluno</Label>
                <Input 
                    id="shareId" 
                    value={shareId} 
                    onChange={e => setShareId(e.target.value)} 
                    placeholder="Ex: ABC12345"
                    required 
                />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            {success && <p className="text-sm text-green-600">{success}</p>}
            <DialogFooter>
                <DialogClose asChild>
                    <Button type="button" variant="secondary">Fechar</Button>
                </DialogClose>
                <Button type="submit" disabled={isLinking} className="bg-orange-500 hover:bg-orange-600 text-white">
                    {isLinking ? 'Vinculando...' : 'Vincular Aluno'}
                </Button>
            </DialogFooter>
        </form>
    );
};

export default function Dashboard() {
  const [stats, setStats] = useState({ 
    activeStudents: 0, 
    workoutPlans: 0, 
    dietPlans: 0, 
    progressPercentage: 0,
    lastMonthStudents: 0,
    newStudentsThisMonth: 0
  });
  const [user, setUser] = useState(null);
  const [students, setStudents] = useState([]);
  const [activities, setActivities] = useState([]);
  const [pendingPayments, setPendingPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);

  useEffect(() => {
    const checkUserRole = async () => {
        try {
            const currentUser = await User.me();
            if (!currentUser.role) {
                // Se o usuário não tem role, ele não deveria estar aqui.
                // Redireciona para completar o perfil.
                window.location.href = createPageUrl('CompleteProfile');
                return;
            }
            setUser(currentUser);
            fetchData(currentUser);
        } catch (error) {
            // Se houver erro (não logado), redireciona para a landing.
            window.location.href = createPageUrl('Landing');
        }
    };
    checkUserRole();
  }, []);

  const fetchData = async (currentUser) => {
    if (!currentUser) return; // Adicionado para segurança
    setIsLoading(true);
    try {
      if (currentUser.role === 'trainer') {
          // Buscar TODOS os usuários primeiro
          const allUsers = await User.list(); // Alterado para User.list()
          
          // Filtrar manualmente os alunos vinculados a este trainer
          const trainerStudents = allUsers.filter(user => 
              user.role === 'student' && 
              user.linked_trainer_email === currentUser.email
          );

          // Buscar dados do trainer
          const [trainerWorkouts, trainerDiets] = await Promise.all([
              WorkoutPlan.filter({ trainer_email: currentUser.email }),
              DietPlan.filter({ trainer_email: currentUser.email })
          ]);

          // Buscar ou criar atividades recentes
          let trainerActs = await RecentActivity.filter({ trainer_email: currentUser.email }, '-created_date', 10);
          
          // Se não há atividades recentes, criar algumas baseadas nos dados reais
          if (trainerActs.length === 0) {
              const activitiesToCreate = [];
              
              if (trainerStudents.length > 0) {
                  activitiesToCreate.push({
                      trainer_email: currentUser.email,
                      description: `${trainerStudents.length} aluno${trainerStudents.length !== 1 ? 's' : ''} vinculado${trainerStudents.length !== 1 ? 's' : ''} ao seu perfil`,
                      link_to: createPageUrl('Students')
                  });
              }
              
              if (trainerWorkouts.length > 0) {
                  activitiesToCreate.push({
                      trainer_email: currentUser.email,
                      description: `${trainerWorkouts.length} treino${trainerWorkouts.length !== 1 ? 's' : ''} criado${trainerWorkouts.length !== 1 ? 's' : ''}`,
                      link_to: createPageUrl('Workouts')
                  });
              }
              
              if (trainerDiets.length > 0) {
                  activitiesToCreate.push({
                      trainer_email: currentUser.email,
                      description: `${trainerDiets.length} dieta${trainerDiets.length !== 1 ? 's' : ''} criada${trainerDiets.length !== 1 ? 's' : ''}`,
                      link_to: createPageUrl('Diets')
                  });
              }
              
              if (activitiesToCreate.length === 0) {
                  activitiesToCreate.push({
                      trainer_email: currentUser.email,
                      description: 'Bem-vindo ao MisterFit! Comece vinculando seus alunos.',
                      link_to: createPageUrl('Students')
                  });
              }
              
              // Criar atividades
              try {
                  for (const activity of activitiesToCreate) {
                      await RecentActivity.create(activity);
                  }
                  
                  // Buscar novamente as atividades após criar
                  trainerActs = await RecentActivity.filter({ trainer_email: currentUser.email }, '-created_date', 10);
              } catch (activityError) {
                  console.error('Erro ao criar atividades:', activityError);
              }
          }

          // Calcular crescimento mensal
          const oneMonthAgo = subMonths(new Date(), 1);
          const studentsLastMonth = trainerStudents.filter(s => 
              new Date(s.created_date) <= oneMonthAgo
          ).length;
          
          const studentsThisMonth = trainerStudents.filter(s => 
              new Date(s.created_date) > oneMonthAgo
          ).length;
          
          const currentStudents = trainerStudents.length;
          const growth = studentsLastMonth > 0 
              ? Math.round(((currentStudents - studentsLastMonth) / studentsLastMonth) * 100)
              : currentStudents > 0 ? 100 : 0;

          // Buscar pagamentos pendentes apenas se houver alunos
          let payments = [];
          if (trainerStudents.length > 0) {
              const studentEmails = trainerStudents.map(s => s.email);
              const allPayments = await Payment.list();
              payments = allPayments.filter(p => 
                  studentEmails.includes(p.student_email) && 
                  (p.status === 'pendente' || p.status === 'atrasado')
              );
          }

          setStats({
              activeStudents: currentStudents,
              workoutPlans: trainerWorkouts.length,
              dietPlans: trainerDiets.length,
              progressPercentage: Math.max(0, growth),
              lastMonthStudents: studentsLastMonth,
              newStudentsThisMonth: studentsThisMonth
          });
          
          setStudents(trainerStudents);
          setActivities(trainerActs);
          setPendingPayments(payments);

      } else if (currentUser.role === 'admin') {
          const allUsers = await User.list();
          const [students, workouts, diets, acts, payments] = await Promise.all([
              allUsers.filter(u => u.role === 'student'),
              WorkoutPlan.list(),
              DietPlan.list(),
              RecentActivity.list('-created_date', 10),
              Payment.filter({ status: ['pendente', 'atrasado'] })
          ]);
          
          setStats({
              activeStudents: students.length,
              workoutPlans: workouts.length,
              dietPlans: diets.length,
              progressPercentage: 15
          });
          
          setStudents(students);
          setActivities(acts);
          setPendingPayments(payments);
      }

    } catch (error) {
      console.error("Erro ao buscar dados do dashboard:", error);
    }
    setIsLoading(false);
  };

  const handleStudentLinked = () => {
    setIsFormOpen(false);
    fetchData(user); // Pass the current user to re-fetch data
  };

  if (!user) { // Adicionado para evitar renderização antes do usuário ser verificado
      return (
          <div className="flex items-center justify-center h-64">
              <p>Verificando...</p>
          </div>
      );
  }

  return (
    <div className="space-y-6">
      {/* Header com foto e nome do personal */}
      <div className="flex items-center gap-4">
        <Avatar className="w-16 h-16">
          <AvatarImage src={user?.profile_photo} />
          <AvatarFallback className="text-xl bg-orange-100 text-orange-600">
            {user?.full_name?.[0]?.toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">
            Olá, {user ? user.full_name.split(' ')[0] : 'Personal'}!
          </h1>
          <p className="text-gray-500">
            Bem-vindo de volta! Aqui está um resumo da sua atividade.
          </p>
          <Badge className="mt-1 bg-blue-100 text-blue-800 capitalize">
            {user?.role === 'trainer' ? 'Personal Trainer' : user?.role}
          </Badge>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Alunos Ativos" 
          value={stats.activeStudents} 
          subtext={stats.activeStudents === 0 ? "Adicione seu primeiro aluno" : `${stats.newStudentsThisMonth} novo${stats.newStudentsThisMonth !== 1 ? 's' : ''} este mês`}
          icon={Users} 
          isLoading={isLoading} 
          link={stats.activeStudents > 0 ? createPageUrl('Students') : null}
          action={stats.activeStudents === 0 ? () => setIsFormOpen(true) : null}
          variant={stats.activeStudents === 0 ? 'highlight' : 'normal'}
        />
        <StatCard 
          title="Treinos Criados" 
          value={stats.workoutPlans} 
          subtext={stats.workoutPlans === 0 ? "Crie seu primeiro treino" : `${Math.round(stats.workoutPlans / Math.max(stats.activeStudents, 1) * 100) / 100} por aluno`}
          icon={ClipboardList} 
          isLoading={isLoading} 
          link={createPageUrl('Workouts')}
        />
        <StatCard 
          title="Dietas Criadas" 
          value={stats.dietPlans} 
          subtext={stats.dietPlans === 0 ? "Crie sua primeira dieta" : `${Math.round(stats.dietPlans / Math.max(stats.activeStudents, 1) * 100) / 100} por aluno`}
          icon={Salad} 
          isLoading={isLoading} 
          link={createPageUrl('Diets')}
        />
        <StatCard 
          title="Crescimento" 
          value={`${stats.progressPercentage >= 0 ? '+' : ''}${stats.progressPercentage}%`} 
          subtext={stats.progressPercentage > 0 ? "Crescimento este mês" : stats.progressPercentage < 0 ? "Redução este mês" : "Sem variação este mês"}
          icon={TrendingUp} 
          isLoading={isLoading} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AttentionPayments payments={pendingPayments} students={students} isLoading={isLoading} />
        <RecentActivities activities={activities} isLoading={isLoading} />
      </div>

      {/* Modal para vincular aluno */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Vincular Novo Aluno</DialogTitle>
            <DialogDescription>
              Insira o ID de compartilhamento fornecido pelo seu aluno para vinculá-lo à sua conta.
            </DialogDescription>
          </DialogHeader>
          {user && <LinkStudentForm trainer={user} onStudentLinked={handleStudentLinked} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

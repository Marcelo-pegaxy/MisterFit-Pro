import React, { useState, useEffect } from 'react';
import { Assessment } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ClipboardCheck, Calendar, TrendingUp, TrendingDown, Activity, User, Target, AlertCircle } from 'lucide-react';
import { format, compareAsc } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const ProgressComparison = ({ current, previous, label, unit = '', isPercentage = false }) => {
    if (!current || !previous) return null;
    
    const currentVal = parseFloat(current);
    const previousVal = parseFloat(previous);
    
    if (isNaN(currentVal) || isNaN(previousVal)) return null;
    
    const difference = currentVal - previousVal;
    const percentChange = (difference / previousVal) * 100;
    
    const isImprovement = label === 'Peso' ? difference < 0 : difference > 0;
    
    return (
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div>
                <p className="font-medium">{label}</p>
                <p className="text-2xl font-bold">
                    {currentVal}{unit}{isPercentage && '%'}
                </p>
            </div>
            <div className="text-right">
                <div className={`flex items-center gap-1 ${isImprovement ? 'text-green-600' : 'text-red-600'}`}>
                    {difference > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    <span className="font-medium">
                        {difference > 0 ? '+' : ''}{difference.toFixed(1)}{unit}{isPercentage && '%'}
                    </span>
                </div>
                <p className="text-xs text-gray-500">
                    {Math.abs(percentChange).toFixed(1)}% vs. anterior
                </p>
            </div>
        </div>
    );
};

const AssessmentCard = ({ assessment, previousAssessment, isLatest }) => {
    const hasPhysicalData = assessment.weight || assessment.height || assessment.bmi || assessment.body_fat_percentage;
    const hasTests = assessment.strength_tests || assessment.flexibility_tests || assessment.cardio_tests;
    
    return (
        <Card className={`mb-6 ${isLatest ? 'ring-2 ring-orange-200 bg-orange-50/30' : ''}`}>
            <CardHeader>
                <div className="flex items-start justify-between">
                    <div>
                        <div className="flex items-center gap-2 mb-2">
                            <CardTitle className="text-xl">
                                Avaliação de {format(new Date(assessment.assessment_date), 'dd/MM/yyyy')}
                            </CardTitle>
                            {isLatest && (
                                <Badge className="bg-orange-100 text-orange-800">Mais Recente</Badge>
                            )}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Calendar className="w-4 h-4" />
                            <span>{format(new Date(assessment.assessment_date), "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</span>
                        </div>
                    </div>
                </div>
            </CardHeader>
            
            <CardContent className="space-y-6">
                {/* Dados Físicos */}
                {hasPhysicalData && (
                    <div>
                        <h3 className="font-semibold flex items-center gap-2 mb-4">
                            <Activity className="w-5 h-5 text-blue-500" />
                            Medidas Corporais
                        </h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {assessment.weight && previousAssessment?.weight && (
                                <ProgressComparison 
                                    current={assessment.weight} 
                                    previous={previousAssessment.weight}
                                    label="Peso" 
                                    unit="kg" 
                                />
                            )}
                            
                            {assessment.weight && !previousAssessment?.weight && (
                                <div className="p-3 bg-gray-50 rounded-lg">
                                    <p className="font-medium">Peso</p>
                                    <p className="text-2xl font-bold">{assessment.weight}kg</p>
                                </div>
                            )}
                            
                            {assessment.bmi && previousAssessment?.bmi && (
                                <ProgressComparison 
                                    current={assessment.bmi} 
                                    previous={previousAssessment.bmi}
                                    label="IMC" 
                                />
                            )}
                            
                            {assessment.bmi && !previousAssessment?.bmi && (
                                <div className="p-3 bg-gray-50 rounded-lg">
                                    <p className="font-medium">IMC</p>
                                    <p className="text-2xl font-bold">{assessment.bmi}</p>
                                </div>
                            )}
                            
                            {assessment.body_fat_percentage && previousAssessment?.body_fat_percentage && (
                                <ProgressComparison 
                                    current={assessment.body_fat_percentage} 
                                    previous={previousAssessment.body_fat_percentage}
                                    label="Gordura Corporal" 
                                    unit=""
                                    isPercentage={true}
                                />
                            )}
                            
                            {assessment.body_fat_percentage && !previousAssessment?.body_fat_percentage && (
                                <div className="p-3 bg-gray-50 rounded-lg">
                                    <p className="font-medium">Gordura Corporal</p>
                                    <p className="text-2xl font-bold">{assessment.body_fat_percentage}%</p>
                                </div>
                            )}
                            
                            {assessment.height && (
                                <div className="p-3 bg-gray-50 rounded-lg">
                                    <p className="font-medium">Altura</p>
                                    <p className="text-2xl font-bold">{assessment.height}m</p>
                                </div>
                            )}
                            
                            {assessment.muscle_mass && (
                                <div className="p-3 bg-gray-50 rounded-lg">
                                    <p className="font-medium">Massa Muscular</p>
                                    <p className="text-2xl font-bold">{assessment.muscle_mass}</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {/* Objetivos */}
                {assessment.specific_objectives && (
                    <div>
                        <h3 className="font-semibold flex items-center gap-2 mb-3">
                            <Target className="w-5 h-5 text-green-500" />
                            Objetivos Específicos
                        </h3>
                        <div className="p-4 bg-green-50 rounded-lg">
                            <p className="text-green-800">{assessment.specific_objectives}</p>
                        </div>
                    </div>
                )}
                
                {/* Testes de Performance */}
                {hasTests && (
                    <div>
                        <h3 className="font-semibold flex items-center gap-2 mb-4">
                            <TrendingUp className="w-5 h-5 text-purple-500" />
                            Testes de Performance
                        </h3>
                        
                        <div className="space-y-3">
                            {assessment.strength_tests && (
                                <div className="p-3 bg-purple-50 rounded-lg">
                                    <h4 className="font-medium text-purple-800 mb-2">💪 Testes de Força</h4>
                                    <p className="text-purple-700 text-sm">{assessment.strength_tests}</p>
                                </div>
                            )}
                            
                            {assessment.flexibility_tests && (
                                <div className="p-3 bg-blue-50 rounded-lg">
                                    <h4 className="font-medium text-blue-800 mb-2">🤸‍♂️ Testes de Flexibilidade</h4>
                                    <p className="text-blue-700 text-sm">{assessment.flexibility_tests}</p>
                                </div>
                            )}
                            
                            {assessment.cardio_tests && (
                                <div className="p-3 bg-red-50 rounded-lg">
                                    <h4 className="font-medium text-red-800 mb-2">❤️ Testes Cardiovasculares</h4>
                                    <p className="text-red-700 text-sm">{assessment.cardio_tests}</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {/* Limitações e Histórico */}
                {(assessment.physical_limitations || assessment.health_history) && (
                    <div>
                        <h3 className="font-semibold flex items-center gap-2 mb-4">
                            <AlertCircle className="w-5 h-5 text-yellow-500" />
                            Informações Importantes
                        </h3>
                        
                        <div className="space-y-3">
                            {assessment.physical_limitations && (
                                <div className="p-3 bg-yellow-50 rounded-lg">
                                    <h4 className="font-medium text-yellow-800 mb-2">⚠️ Limitações Físicas</h4>
                                    <p className="text-yellow-700 text-sm">{assessment.physical_limitations}</p>
                                </div>
                            )}
                            
                            {assessment.health_history && (
                                <div className="p-3 bg-gray-50 rounded-lg">
                                    <h4 className="font-medium text-gray-800 mb-2">📋 Histórico de Saúde</h4>
                                    <p className="text-gray-700 text-sm">{assessment.health_history}</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {/* Observações Gerais */}
                {assessment.general_observations && (
                    <div>
                        <h3 className="font-semibold flex items-center gap-2 mb-3">
                            <User className="w-5 h-5 text-gray-500" />
                            Observações do Personal
                        </h3>
                        <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="text-gray-700">{assessment.general_observations}</p>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default function StudentAssessments() {
    const [assessments, setAssessments] = useState([]);
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchAssessments = async () => {
            try {
                const storedUser = localStorage.getItem('currentUser');
                if (!storedUser) {
                    setIsLoading(false);
                    return;
                }

                const currentUser = JSON.parse(storedUser);
                setUser(currentUser);

                // Buscar avaliações do aluno ordenadas por data
                const userAssessments = await Assessment.filter(
                    { student_email: currentUser.email },
                    '-assessment_date'
                );
                
                setAssessments(userAssessments);
            } catch (error) {
                console.error("Erro ao buscar avaliações:", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchAssessments();
    }, []);

    if (isLoading) {
        return (
            <div className="space-y-4">
                <Skeleton className="h-8 w-1/3" />
                <Skeleton className="h-4 w-2/3" />
                <div className="space-y-4">
                    {Array(2).fill(0).map((_, i) => (
                        <Card key={i}>
                            <CardHeader>
                                <Skeleton className="h-6 w-1/2" />
                                <Skeleton className="h-4 w-full" />
                            </CardHeader>
                            <CardContent>
                                <Skeleton className="h-32 w-full" />
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
                    <ClipboardCheck className="w-8 h-8 text-purple-500" />
                    Minhas Avaliações
                </h1>
                <p className="text-gray-500 mt-2">
                    {assessments.length > 0 
                        ? `Você tem ${assessments.length} avaliação${assessments.length !== 1 ? 'ões' : ''} registrada${assessments.length !== 1 ? 's' : ''}.`
                        : 'Suas avaliações físicas aparecerão aqui quando seu personal trainer as registrar.'
                    }
                </p>
            </div>

            {assessments.length > 0 ? (
                <div>
                    {assessments.map((assessment, index) => (
                        <AssessmentCard 
                            key={assessment.id} 
                            assessment={assessment} 
                            previousAssessment={assessments[index + 1]}
                            isLatest={index === 0}
                        />
                    ))}
                </div>
            ) : (
                <Card>
                    <CardContent className="text-center py-16">
                        <div className="flex flex-col items-center gap-4">
                            <div className="p-4 bg-gray-100 rounded-full">
                                <ClipboardCheck className="w-12 h-12 text-gray-400" />
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold text-gray-600 mb-2">
                                    Nenhuma avaliação registrada
                                </h3>
                                <p className="text-gray-500 max-w-md">
                                    Suas avaliações físicas e de progresso aparecerão aqui quando seu personal trainer as registrar. 
                                    Avaliações regulares são importantes para acompanhar sua evolução!
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
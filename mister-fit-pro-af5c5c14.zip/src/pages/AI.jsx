
import React, { useState, useEffect } from 'react';
import { UserAccount } from '@/api/entities/UserAccount';
import { WorkoutPlan } from '@/api/entities';
import { DietPlan } from '@/api/entities';
import { InvokeLLM, UploadFile } from '@/api/integrations'; // Added UploadFile
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Dumbbell, Utensils, Loader2, Copy, Save, User, Activity, Video } from 'lucide-react'; // Added Activity icon
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input'; // Added Input component

const WorkoutSuggestion = ({ user, students }) => {
  const [formData, setFormData] = useState({
    student_email: '',
    student_profile: '',
    workout_preferences: '',
    available_equipment: '',
  });
  const [suggestion, setSuggestion] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleGenerate = async () => {
    if (!formData.student_profile.trim()) {
      alert('Por favor, preencha pelo menos o perfil do aluno.');
      return;
    }

    setIsGenerating(true);
    try {
      const prompt = `
        Como personal trainer especializado, crie um plano de treino personalizado baseado nas seguintes informações:

        PERFIL DO ALUNO:
        ${formData.student_profile}

        PREFERÊNCIAS DE TREINO:
        ${formData.workout_preferences || 'Não especificado'}

        EQUIPAMENTOS DISPONÍVEIS:
        ${formData.available_equipment || 'Equipamentos básicos de academia'}

        Por favor, crie um plano de treino completo e estruturado com:
        1. Nome do treino
        2. Descrição e objetivos
        3. Lista detalhada de exercícios (pelo menos 6-8 exercícios)
        4. Para cada exercício: nome, séries, repetições, intensidade, descanso, observações de execução
        5. Frequência recomendada e progressão sugerida

        Formate a resposta de forma clara e profissional.
      `;

      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            description: { type: "string" },
            exercises: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  exercise_name: { type: "string" },
                  sets: { type: "string" },
                  reps: { type: "string" },
                  intensity: { type: "string" },
                  rest_interval: { type: "string" },
                  recommended_frequency: { type: "string" },
                  execution_notes: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSuggestion(response);
    } catch (error) {
      console.error('Erro ao gerar sugestão:', error);
      alert('Erro ao gerar sugestão. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveWorkout = async () => {
    if (!suggestion) return;

    setIsSaving(true);
    try {
      await WorkoutPlan.create({
        name: suggestion.name,
        description: suggestion.description,
        trainer_email: user.email,
        student_email: formData.student_email || null,
        exercises: suggestion.exercises || []
      });
      
      alert('Treino salvo com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar treino:', error);
      alert('Erro ao salvar treino. Tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Formulário */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-500" />
            Informações para a IA
          </CardTitle>
          <p className="text-sm text-gray-500">Forneça detalhes para a IA criar a melhor sugestão de treino.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {students.length > 0 && (
            <div>
              <Label>Aluno (Opcional)</Label>
              <Select onValueChange={(value) => setFormData({...formData, student_email: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um aluno ou deixe em branco" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Não atribuir a aluno específico</SelectItem>
                  {students.map(student => (
                    <SelectItem key={student.id} value={student.email}>{student.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label htmlFor="student_profile">Perfil do Aluno *</Label>
            <Textarea
              id="student_profile"
              placeholder="Ex: Homem, 30 anos, 80kg, 1,75m, nível intermediário, objetivo de hipertrofia, sem limitações físicas."
              value={formData.student_profile}
              onChange={(e) => setFormData({...formData, student_profile: e.target.value})}
              className="h-24"
            />
          </div>

          <div>
            <Label htmlFor="workout_preferences">Preferências de Treino</Label>
            <Textarea
              id="workout_preferences"
              placeholder="Ex: Prefere treinos 3-4x por semana, duração de 60 minutos, gosta de exercícios compostos como agachamento, supino."
              value={formData.workout_preferences}
              onChange={(e) => setFormData({...formData, workout_preferences: e.target.value})}
              className="h-20"
            />
          </div>

          <div>
            <Label htmlFor="available_equipment">Equipamentos Disponíveis</Label>
            <Textarea
              id="available_equipment"
              placeholder="Ex: Barra olímpica, anilhas, halteres variados, banco ajustável, barra fixa, esteira, bicicleta."
              value={formData.available_equipment}
              onChange={(e) => setFormData({...formData, available_equipment: e.target.value})}
              className="h-20"
            />
          </div>

          <Button 
            onClick={handleGenerate} 
            disabled={isGenerating || !formData.student_profile.trim()}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Gerando Sugestão...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Gerar Sugestão de Treino
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Resultado */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-green-500" />
            Sugestão Gerada
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isGenerating ? (
            <div className="space-y-4">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : suggestion ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold">{suggestion.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{suggestion.description}</p>
              </div>

              {suggestion.exercises && suggestion.exercises.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Exercícios ({suggestion.exercises.length})</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {suggestion.exercises.map((exercise, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg text-sm">
                        <div className="font-medium">{exercise.exercise_name}</div>
                        <div className="text-gray-600 mt-1">
                          {exercise.sets && `${exercise.sets} séries`}
                          {exercise.reps && ` • ${exercise.reps} reps`}
                          {exercise.rest_interval && ` • ${exercise.rest_interval} descanso`}
                        </div>
                        {exercise.execution_notes && (
                          <div className="text-xs text-gray-500 mt-1">{exercise.execution_notes}</div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  onClick={handleSaveWorkout}
                  disabled={isSaving}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Salvar como Treino
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Sparkles className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Pronto para uma sugestão?</h3>
              <p className="text-gray-500">Preencha o formulário para que nossa IA crie um plano de treino para você.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

const MovementAnalysis = ({ user, students }) => {
  const [formData, setFormData] = useState({
    student_email: '',
    exercise_name: '',
    video_file: null, // This state is not directly used for the prompt, but good for form handling
    additional_notes: '',
  });
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState('');

  const handleVideoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) {
      setUploadedVideoUrl(''); // Clear URL if no file selected
      setFormData(prev => ({...prev, video_file: null}));
      return;
    }

    if (!file.type.startsWith('video/')) {
      alert('Por favor, selecione um arquivo de vídeo válido.');
      e.target.value = null; // Clear the input field
      setUploadedVideoUrl('');
      setFormData(prev => ({...prev, video_file: null}));
      return;
    }

    // Basic size check (e.g., 50MB)
    const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50 MB
    if (file.size > MAX_FILE_SIZE) {
      alert('O arquivo de vídeo é muito grande. Por favor, selecione um vídeo com menos de 50MB.');
      e.target.value = null; // Clear the input field
      setUploadedVideoUrl('');
      setFormData(prev => ({...prev, video_file: null}));
      return;
    }

    setIsAnalyzing(true); // Indicate that upload is in progress (briefly)
    try {
      const { file_url } = await UploadFile({ file });
      setUploadedVideoUrl(file_url);
      setFormData(prev => ({...prev, video_file: file})); // Store the actual file object too if needed
    } catch (error) {
      console.error('Erro no upload do vídeo:', error);
      alert('Erro ao fazer upload do vídeo. Tente novamente.');
      setUploadedVideoUrl('');
      setFormData(prev => ({...prev, video_file: null}));
    } finally {
      setIsAnalyzing(false); // Reset analysis state after upload
    }
  };

  const handleAnalyze = async () => {
    if (!formData.student_email) {
      alert('Por favor, selecione o aluno.');
      return;
    }
    if (!formData.exercise_name.trim()) {
      alert('Por favor, preencha o nome do exercício.');
      return;
    }
    if (!uploadedVideoUrl) {
      alert('Por favor, faça upload do vídeo do exercício.');
      return;
    }

    setIsAnalyzing(true);
    setAnalysis(null); // Clear previous analysis
    try {
      const prompt = `
        Como especialista em biomecânica e análise de movimento, analise o vídeo do exercício fornecido e forneça um relatório detalhado:

        INFORMAÇÕES DO EXERCÍCIO:
        Aluno: ${students.find(s => s.email === formData.student_email)?.full_name || 'Aluno Não Selecionado'}
        Exercício: ${formData.exercise_name}
        Observações adicionais: ${formData.additional_notes || 'Nenhuma'}

        Por favor, forneça uma análise completa incluindo:

        1. ANÁLISE BIOMECÂNICA DETALHADA:
        - Postura geral e alinhamento corporal durante as fases do movimento.
        - Qualidade do movimento (fluidez, controle, amplitude, trajetória).
        - Ativação muscular aparente e sinergia entre grupos musculares.
        - Descrição das fases excêntrica, concêntrica e isométrica, se aplicável.

        2. ERROS TÉCNICOS DETECTADOS:
        - Liste os problemas específicos de forma e técnica.
        - Identifique compensações musculares ou padrões de movimento disfuncionais.
        - Para cada erro, descreva a causa provável e o impacto na performance/segurança.

        3. PREDIÇÃO DE RISCOS E VULNERABILIDADES:
        - Possíveis lesões futuras se o padrão de movimento atual for mantido.
        - Áreas do corpo que estão sob maior estresse ou vulnerabilidade.
        - Nível de risco geral (Baixo, Médio, Alto).

        4. RECOMENDAÇÕES CORRETIVAS:
        - Ajustes imediatos na técnica a serem implementados.
        - Exercícios preparatórios, educativos ou corretivos específicos.
        - Sugestões de mobilidade, flexibilidade ou fortalecimento direcionado.

        5. PLANO DE PROGRESSÃO SUGERIDO:
        - Indicações de quando e como evoluir a carga, intensidade ou complexidade do exercício.
        - Variações do exercício ou exercícios complementares para melhorar a técnica.
        - Marcos de melhoria esperados e como monitorá-los.

        6. PONTUAÇÃO GERAL DE EXECUÇÃO:
        - Atribua uma pontuação de 1 a 10 para a qualidade geral da execução do exercício.

        7. RESUMO EXECUTIVO:
        - Um breve parágrafo sintetizando os principais pontos da análise.

        Seja específico, técnico, utilize termos da biomecânica e foque na prevenção de lesões e otimização da performance.
      `;

      const response = await InvokeLLM({
        prompt: prompt,
        file_urls: [uploadedVideoUrl],
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            overall_score: { type: "number" },
            biomechanical_analysis: { type: "string" },
            detected_errors: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  error_type: { type: "string" },
                  severity: { type: "string", enum: ["Leve", "Moderado", "Grave"] },
                  description: { type: "string" }
                },
                required: ["error_type", "severity", "description"]
              }
            },
            injury_risk: {
              type: "object",
              properties: {
                risk_level: { type: "string", enum: ["Baixo", "Médio", "Alto"] },
                vulnerable_areas: { type: "array", items: { type: "string" }},
                predicted_injuries: { type: "array", items: { type: "string" }}
              },
              required: ["risk_level", "vulnerable_areas"]
            },
            corrective_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  recommendation: { type: "string" },
                  priority: { type: "string", enum: ["Baixa", "Média", "Alta"] }
                },
                required: ["category", "recommendation", "priority"]
              }
            },
            progression_plan: { type: "string" },
          },
          required: ["summary", "overall_score", "biomechanical_analysis", "detected_errors", "injury_risk", "corrective_recommendations", "progression_plan"]
        }
      });

      setAnalysis(response);
    } catch (error) {
      console.error('Erro ao analisar movimento:', error);
      alert(`Erro ao analisar movimento. Tente novamente. Detalhes: ${error.message || 'Erro desconhecido'}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getRiskColor = (level) => {
    switch(level?.toLowerCase()) {
      case 'baixo': return 'text-green-600 bg-green-100';
      case 'médio': return 'text-yellow-600 bg-yellow-100';
      case 'alto': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getSeverityColor = (severity) => {
    switch(severity?.toLowerCase()) {
      case 'leve': return 'bg-blue-100 text-blue-800';
      case 'moderado': return 'bg-yellow-100 text-yellow-800';
      case 'grave': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Formulário */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            Análise de Movimento
          </CardTitle>
          <p className="text-sm text-gray-500">Faça upload de um vídeo do exercício para análise biomecânica detalhada.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Aluno *</Label>
            <Select onValueChange={(value) => setFormData({...formData, student_email: value})} value={formData.student_email || ''}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o aluno" />
              </SelectTrigger>
              <SelectContent>
                {students.map(student => (
                  <SelectItem key={student.id} value={student.email}>{student.full_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="exercise_name">Nome do Exercício *</Label>
            <Input
              id="exercise_name"
              value={formData.exercise_name}
              onChange={(e) => setFormData({...formData, exercise_name: e.target.value})}
              placeholder="Ex: Agachamento, Supino, Deadlift..."
            />
          </div>

          <div>
            <Label htmlFor="video_upload">Vídeo do Exercício *</Label>
            <div className="mt-2">
              <input
                id="video_upload"
                type="file"
                accept="video/*"
                onChange={handleVideoUpload}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"
              />
              {uploadedVideoUrl && (
                <div className="mt-3">
                  <video 
                    src={uploadedVideoUrl} 
                    controls 
                    className="w-full max-h-48 rounded-lg border border-gray-200"
                  />
                  <p className="text-xs text-green-600 mt-1">✓ Vídeo carregado com sucesso</p>
                </div>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="additional_notes">Observações Adicionais</Label>
            <Textarea
              id="additional_notes"
              placeholder="Ex: Aluno relata dor no joelho, primeira vez fazendo este exercício, usar carga reduzida..."
              value={formData.additional_notes}
              onChange={(e) => setFormData({...formData, additional_notes: e.target.value})}
              className="h-20"
            />
          </div>

          <Button 
            onClick={handleAnalyze} 
            disabled={isAnalyzing || !formData.student_email || !formData.exercise_name.trim() || !uploadedVideoUrl}
            className="w-full bg-purple-500 hover:bg-purple-600 text-white"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analisando Movimento... (30-60s)
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Analisar Movimento
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Resultado da Análise */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-green-500" />
            Relatório da Análise
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isAnalyzing ? (
            <div className="space-y-4">
              <div className="text-center py-4">
                <Loader2 className="w-8 h-8 animate-spin text-purple-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Analisando biomecânica do vídeo...</p>
                <p className="text-xs text-gray-500">Isso pode levar de 30 a 60 segundos dependendo do vídeo.</p>
              </div>
              <div className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            </div>
          ) : analysis ? (
            <div className="space-y-6 max-h-[70vh] overflow-y-auto p-1"> {/* Added p-1 for slight padding */}
              {/* Score Geral */}
              {typeof analysis.overall_score === 'number' && (
                <div className="text-center p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                  <div className="text-3xl font-bold text-purple-600 mb-1">
                    {analysis.overall_score.toFixed(0)}/10
                  </div>
                  <p className="text-sm text-gray-600">Qualidade da Execução</p>
                </div>
              )}

              {/* Resumo */}
              {analysis.summary && (
                <div>
                  <h4 className="font-semibold mb-2 text-gray-800">📋 Resumo Executivo</h4>
                  <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-lg leading-relaxed">{analysis.summary}</p>
                </div>
              )}

              {/* Análise Biomecânica Detalhada */}
              {analysis.biomechanical_analysis && (
                <div>
                  <h4 className="font-semibold mb-2 text-gray-800">🔬 Análise Biomecânica Detalhada</h4>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg leading-relaxed">{analysis.biomechanical_analysis}</p>
                </div>
              )}

              {/* Erros Detectados */}
              {analysis.detected_errors && analysis.detected_errors.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2 text-gray-800">🎯 Erros Técnicos Detectados</h4>
                  <div className="space-y-3">
                    {analysis.detected_errors.map((error, idx) => (
                      <div key={idx} className="border-l-4 border-red-400 pl-3 py-2 bg-red-50 rounded-sm">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm text-gray-900">{error.error_type}</span>
                          <Badge className={getSeverityColor(error.severity)}>{error.severity}</Badge>
                        </div>
                        <p className="text-xs text-gray-700 leading-relaxed">{error.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Nível de Risco */}
              {analysis.injury_risk && (
                <div>
                  <h4 className="font-semibold mb-2 text-gray-800">⚠️ Predição de Riscos e Vulnerabilidades</h4>
                  <div className="space-y-2">
                    <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(analysis.injury_risk.risk_level)}`}>
                      Risco Geral: {analysis.injury_risk.risk_level}
                    </div>
                    
                    {analysis.injury_risk.vulnerable_areas && analysis.injury_risk.vulnerable_areas.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-600 mt-2 mb-1">Áreas do Corpo Vulneráveis:</p>
                        <div className="flex flex-wrap gap-1">
                          {analysis.injury_risk.vulnerable_areas.map((area, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">{area}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {analysis.injury_risk.predicted_injuries && analysis.injury_risk.predicted_injuries.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-600 mt-2 mb-1">Lesões Preditas (se o padrão continuar):</p>
                        <ul className="list-disc list-inside text-xs text-gray-700 space-y-1">
                          {analysis.injury_risk.predicted_injuries.map((injury, idx) => (
                            <li key={idx}>{injury}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Recomendações */}{/* Recomendações */}
              {analysis.corrective_recommendations && analysis.corrective_recommendations.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2 text-gray-800">💡 Recomendações Corretivas</h4>
                  <div className="space-y-3">
                    {analysis.corrective_recommendations.map((rec, idx) => (
                      <div key={idx} className="border-l-4 border-blue-400 pl-3 py-2 bg-blue-50 rounded-sm">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm text-gray-900">{rec.category}</span>
                          <Badge variant={rec.priority === 'Alta' ? 'destructive' : rec.priority === 'Média' ? 'yellow' : 'secondary'} className="text-xs">
                            {rec.priority}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-700 leading-relaxed">{rec.recommendation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Plano de Progressão */}
              {analysis.progression_plan && (
                <div>
                  <h4 className="font-semibold mb-2 text-gray-800">📈 Plano de Progressão Sugerido</h4>
                  <p className="text-sm text-gray-700 bg-green-50 p-3 rounded-lg leading-relaxed">{analysis.progression_plan}</p>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Pronto para analisar?</h3>
              <p className="text-gray-500 mb-2">Faça upload de um vídeo do exercício para receber:</p>
              <ul className="text-sm text-gray-400 text-left max-w-xs mx-auto space-y-1">
                <li>• Análise biomecânica detalhada</li>
                <li>• Detecção de erros técnicos</li>
                <li>• Predição de riscos de lesão</li>
                <li>• Recomendações corretivas</li>
                <li>• Plano de progressão personalizado</li>
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

const DietSuggestion = ({ user, students }) => {
  const [formData, setFormData] = useState({
    student_email: '',
    student_profile: '',
    dietary_preferences: '',
    health_conditions: '',
  });
  const [suggestion, setSuggestion] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleGenerate = async () => {
    if (!formData.student_profile.trim()) {
      alert('Por favor, preencha pelo menos o perfil do aluno.');
      return;
    }

    setIsGenerating(true);
    try {
      const prompt = `
        Como nutricionista especializado, crie um plano alimentar personalizado baseado nas seguintes informações:

        PERFIL DO ALUNO:
        ${formData.student_profile}

        PREFERÊNCIAS ALIMENTARES:
        ${formData.dietary_preferences || 'Não especificado'}

        CONDIÇÕES DE SAÚDE/RESTRIÇÕES:
        ${formData.health_conditions || 'Nenhuma restrição conhecida'}

        Por favor, crie um plano alimentar completo e estruturado com:
        1. Nome do plano
        2. Descrição e objetivos nutricionais
        3. Lista de refeições (pelo menos 4-5 refeições diárias)
        4. Para cada refeição: nome, horário sugerido, lista de alimentos com quantidades
        5. Observações nutricionais importantes

        Formate a resposta de forma clara e profissional.
      `;

      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            description: { type: "string" },
            meals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  meal_name: { type: "string" },
                  time: { type: "string" },
                  foods: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        food_name: { type: "string" },
                        quantity: { type: "string" },
                        calories: { type: "string" },
                        macros: { type: "string" }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      });

      setSuggestion(response);
    } catch (error) {
      console.error('Erro ao gerar sugestão:', error);
      alert('Erro ao gerar sugestão. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveDiet = async () => {
    if (!suggestion) return;

    setIsSaving(true);
    try {
      await DietPlan.create({
        name: suggestion.name,
        description: suggestion.description,
        trainer_email: user.email,
        student_email: formData.student_email || null,
        meals: suggestion.meals || []
      });
      
      alert('Dieta salva com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar dieta:', error);
      alert('Erro ao salvar dieta. Tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Formulário */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-500" />
            Informações para a IA
          </CardTitle>
          <p className="text-sm text-gray-500">Forneça detalhes para a IA criar a melhor sugestão de dieta.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {students.length > 0 && (
            <div>
              <Label>Aluno (Opcional)</Label>
              <Select onValueChange={(value) => setFormData({...formData, student_email: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um aluno ou deixe em branco" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Não atribuir a aluno específico</SelectItem>
                  {students.map(student => (
                    <SelectItem key={student.id} value={student.email}>{student.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label htmlFor="student_profile">Perfil do Aluno *</Label>
            <Textarea
              id="student_profile"
              placeholder="Ex: Mulher, 25 anos, 65kg, 1,65m, objetivo de emagrecimento, pratica exercícios 4x por semana."
              value={formData.student_profile}
              onChange={(e) => setFormData({...formData, student_profile: e.target.value})}
              className="h-24"
            />
          </div>

          <div>
            <Label htmlFor="dietary_preferences">Preferências Alimentares</Label>
            <Textarea
              id="dietary_preferences"
              placeholder="Ex: Não gosta de peixes, prefere carnes brancas, adora frutas, evita doces, gosta de saladas."
              value={formData.dietary_preferences}
              onChange={(e) => setFormData({...formData, dietary_preferences: e.target.value})}
              className="h-20"
            />
          </div>

          <div>
            <Label htmlFor="health_conditions">Condições de Saúde/Restrições</Label>
            <Textarea
              id="health_conditions"
              placeholder="Ex: Intolerância à lactose, diabético tipo 2, hipertensão, não pode consumir glúten."
              value={formData.health_conditions}
              onChange={(e) => setFormData({...formData, health_conditions: e.target.value})}
              className="h-20"
            />
          </div>

          <Button 
            onClick={handleGenerate} 
            disabled={isGenerating || !formData.student_profile.trim()}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Gerando Sugestão...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Gerar Sugestão de Dieta
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Resultado */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Utensils className="w-5 h-5 text-green-500" />
            Sugestão Gerada
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isGenerating ? (
            <div className="space-y-4">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : suggestion ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold">{suggestion.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{suggestion.description}</p>
              </div>

              {suggestion.meals && suggestion.meals.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Refeições ({suggestion.meals.length})</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {suggestion.meals.map((meal, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg text-sm">
                        <div className="font-medium">{meal.meal_name}</div>
                        {meal.time && <div className="text-gray-600">Horário: {meal.time}</div>}
                        {meal.foods && meal.foods.length > 0 && (
                          <div className="mt-2 space-y-1">
                            {meal.foods.map((food, foodIndex) => (
                              <div key={foodIndex} className="text-xs text-gray-700">
                                • {food.food_name} {food.quantity && `- ${food.quantity}`}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  onClick={handleSaveDiet}
                  disabled={isSaving}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Salvar como Dieta
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Sparkles className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Pronto para uma sugestão?</h3>
              <p className="text-gray-500">Preencha o formulário para que nossa IA crie um plano alimentar para você.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default function AI() {
  const [user, setUser] = useState(null);
  const [students, setStudents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const storedUser = localStorage.getItem('currentUser');
        if (storedUser) {
          const currentUser = JSON.parse(storedUser);
          setUser(currentUser);

          // Buscar alunos vinculados
          const allUsers = await UserAccount.list();
          const trainerStudents = allUsers.filter(user => 
            user.linked_trainer_email === currentUser.email && user.role === 'student'
          );
          setStudents(trainerStudents);
        }
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        <p className="ml-2 text-gray-600">Carregando...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <Sparkles className="w-8 h-8 text-orange-500" />
          Sugestão com IA
        </h1>
        <p className="text-gray-500">Utilize inteligência artificial para gerar sugestões e analisar movimentos.</p>
      </div>

      <Tabs defaultValue="workout" className="w-full">
        <TabsList className="grid w-full grid-cols-3"> {/* Changed to grid-cols-3 */}
          <TabsTrigger value="workout" className="flex items-center gap-2">
            <Dumbbell className="w-4 h-4" />
            Sugestão de Treino
          </TabsTrigger>
          <TabsTrigger value="diet" className="flex items-center gap-2">
            <Utensils className="w-4 h-4" />
            Sugestão de Dieta
          </TabsTrigger>
          <TabsTrigger value="movement" className="flex items-center gap-2"> {/* New Tab Trigger */}
            <Activity className="w-4 h-4" />
            Análise de Movimento
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="workout" className="mt-6">
          <WorkoutSuggestion user={user} students={students} />
        </TabsContent>
        
        <TabsContent value="diet" className="mt-6">
          <DietSuggestion user={user} students={students} />
        </TabsContent>

        <TabsContent value="movement" className="mt-6"> {/* New Tab Content */}
          <MovementAnalysis user={user} students={students} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

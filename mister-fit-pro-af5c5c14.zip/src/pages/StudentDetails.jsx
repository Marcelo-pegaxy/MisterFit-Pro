
import React, { useState, useEffect } from 'react';
import { UserAccount } from '@/api/entities/UserAccount';
import { WorkoutPlan } from '@/api/entities';
import { DietPlan } from '@/api/entities';
import { Assessment } from '@/api/entities';
import { StudentFinancials } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, PlusCircle, MoreHorizontal, ListChecks, Utensils, Activity, DollarSign, AlertCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import WorkoutTab from '@/components/student/WorkoutTab';
import DietTab from '@/components/student/DietTab';
// AssessmentForm is no longer directly used in this component, its functionality is moved to AssessmentsTab
// import AssessmentForm from '@/components/assessments/AssessmentForm'; 
import FinancialsTab from '@/components/student/FinancialsTab';
import AssessmentsTab from '@/components/student/AssessmentsTab'; // New import
import { format } from 'date-fns';

const EmptyListState = ({ title, description, onAction, actionText }) => (
    <div className="text-center p-8 border rounded-lg">
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="text-sm text-gray-500 mt-1">{description}</p>
        <Button onClick={onAction} className="mt-4 bg-orange-500 hover:bg-orange-600 text-white">
            <PlusCircle className="mr-2 h-4 w-4" /> {actionText}
        </Button>
    </div>
);

export default function StudentDetails() {
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    // assessments state removed as it's now managed by AssessmentsTab
    const [financials, setFinancials] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [user, setUser] = useState(null);

    const [modal, setModal] = useState({ type: null, isOpen: false });

    const fetchData = async (studentId, trainer) => {
        if (!studentId || !trainer) return;
        setIsLoading(true);
        try {
            const studentData = await UserAccount.get(studentId);
            setStudent(studentData);

            // Fetch only financial data here, assessments are now handled by AssessmentsTab
            const financialData = await StudentFinancials.filter({ student_email: studentData.email });

            setFinancials(financialData.length > 0 ? financialData[0] : null);
        } catch (error) {
            console.error("Erro ao buscar dados do aluno:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const studentId = new URLSearchParams(window.location.search).get('id');
        const storedUser = localStorage.getItem('currentUser');
        if (storedUser) {
            const currentUser = JSON.parse(storedUser);
            setUser(currentUser);
            fetchData(studentId, currentUser);
        } else {
            navigate(createPageUrl('Students'));
        }
    }, []);

    const handleFormFinished = () => {
        // This function now primarily serves to close the generic dialog
        setModal({ type: null, isOpen: false });
        // FinancialsTab now explicitly calls fetchData on update, so no re-fetch needed here
    };

    if (isLoading || !student) {
        return (
            <div className="space-y-6">
                <Skeleton className="h-8 w-48" />
                <div className="flex items-center gap-4">
                    <Skeleton className="h-24 w-24 rounded-full" />
                    <div className="space-y-2">
                        <Skeleton className="h-6 w-64" />
                        <Skeleton className="h-4 w-48" />
                    </div>
                </div>
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-64 w-full" />
            </div>
        );
    }
    
    return (
        <div className="space-y-6">
             <Button variant="outline" onClick={() => navigate(createPageUrl('Students'))}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar para Alunos
            </Button>
            
            <Card>
                <CardHeader className="flex flex-row items-center gap-4">
                     <Avatar className="w-24 h-24">
                        <AvatarImage src={student.profile_photo} />
                        <AvatarFallback className="text-3xl bg-orange-100 text-orange-600">
                            {student.full_name?.[0]?.toUpperCase()}
                        </AvatarFallback>
                    </Avatar>
                    <div>
                        <h1 className="text-3xl font-bold">{student.full_name}</h1>
                        <p className="text-gray-500">{student.email}</p>
                    </div>
                </CardHeader>
            </Card>

            <Tabs defaultValue="workouts" className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="workouts" className="flex items-center gap-2">
                        <ListChecks className="w-4 h-4" />
                        Treinos
                    </TabsTrigger>
                    <TabsTrigger value="diets" className="flex items-center gap-2">
                        <Utensils className="w-4 h-4" />
                        Dietas
                    </TabsTrigger>
                    <TabsTrigger value="assessments" className="flex items-center gap-2">
                        <Activity className="w-4 h-4" />
                        Avaliações
                    </TabsTrigger>
                    <TabsTrigger value="financials" className="flex items-center gap-2">
                        {/* Removed AlertCircle from here as per outline */}
                        <DollarSign className="w-4 h-4" />
                        Financeiro
                    </TabsTrigger>
                    <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                </TabsList>
                
                <TabsContent value="workouts" className="mt-6">
                   <WorkoutTab student={student} trainer={user} />
                </TabsContent>

                <TabsContent value="diets" className="mt-6">
                   <DietTab student={student} trainer={user} />
                </TabsContent>

                 <TabsContent value="assessments" className="mt-6">
                   <AssessmentsTab student={student} trainer={user} />
                </TabsContent>
                
                <TabsContent value="financials" className="mt-6">
                    <FinancialsTab student={student} trainer={user} onUpdate={() => fetchData(student.id, user)}/>
                </TabsContent>

                 <TabsContent value="overview" className="mt-6">
                    <Card>
                        <CardHeader><CardTitle>Visão Geral do Aluno</CardTitle></CardHeader>
                        <CardContent>
                            <p><strong>Email:</strong> {student.email}</p>
                            <p><strong>Telefone:</strong> {student.phone || 'Não informado'}</p>
                            <p><strong>Membro desde:</strong> {format(new Date(student.created_date), 'dd/MM/yyyy')}</p>
                        </CardContent>
                    </Card>
                </TabsContent>

            </Tabs>
            
            <Dialog open={modal.isOpen} onOpenChange={(isOpen) => setModal({ type: null, isOpen })}>
                <DialogContent className="max-w-4xl max-h-[90vh]">
                     <DialogHeader>
                        <DialogTitle></DialogTitle> {/* Assessment-specific title removed */}
                        <DialogDescription></DialogDescription> {/* Assessment-specific description removed */}
                    </DialogHeader>
                    {/* AssessmentForm component removed from here, now handled within AssessmentsTab */}
                </DialogContent>
            </Dialog>
        </div>
    );
}


import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, User as UserIcon, Shield } from 'lucide-react';
import { createPageUrl } from '@/utils';

const generateUniqueId = () => {
    return Math.random().toString(36).substr(2, 8).toUpperCase();
};

const AppLogo = () => (
    <div className="flex items-center justify-center gap-3 mb-8">
        <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ee7cadce2_novologo.png" 
            alt="MisterFit Logo" 
            className="w-12 h-12 object-contain"
        />
        <h1 className="text-3xl font-bold text-gray-800">MisterFit</h1>
    </div>
);

export default function CompleteProfile() {
    const [user, setUser] = useState(null);
    const [role, setRole] = useState(null);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        // Este useEffect agora SÓ busca os dados do usuário para exibir na tela.
        // A lógica de redirecionamento foi MOVIDA para o Layout.js.
        const fetchUserForDisplay = async () => {
            setIsLoading(true);
            try {
                const currentUser = await User.me();
                setUser(currentUser);
            } catch (e) {
                // A lógica do Layout já deve ter lidado com isso.
                console.error("Erro em CompleteProfile, usuário não autenticado:", e);
            } finally {
                setIsLoading(false);
            }
        };
        fetchUserForDisplay();
    }, []);

    const handleSubmit = async () => {
        if (!role) {
            setError('Por favor, selecione um tipo de conta.');
            return;
        }
        setIsSaving(true);
        setError('');

        try {
            const userData = { role };
            
            // Se for aluno, gerar ID único para compartilhamento
            if (role === 'student') {
                userData.unique_share_id = generateUniqueId();
            }
            
            console.log('[CompleteProfile] Atualizando usuário com dados:', userData);
            
            // CORREÇÃO: Usando User.updateMyUserData para o usuário logado atualizar seus próprios dados
            await User.updateMyUserData(userData);
            
            console.log('[CompleteProfile] Usuário atualizado com sucesso');
            
            // Aguardar um pouco para garantir que a atualização foi processada
            // O Layout cuidará do redirecionamento, mas vamos forçar aqui para garantir
            setTimeout(() => {
                const redirectPage = role === 'student' ? 'StudentDashboard' : 'dashboard';
                console.log('[CompleteProfile] Redirecionando após cadastro para:', redirectPage);
                window.location.href = createPageUrl(redirectPage);
            }, 500);

        } catch (err) {
            console.error("[CompleteProfile] Erro ao atualizar perfil do usuário:", err);
            setError('Ocorreu um erro ao salvar seu perfil. Tente novamente.');
            setIsSaving(false);
        }
    };

    if (isLoading || !user) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin text-orange-500 mx-auto mb-4" />
                    <p className="text-gray-500">Carregando...</p>
                </div>
            </div>
        );
    }
    
    // O JSX restante permanece o mesmo
    return (
        <div className="bg-gray-50 min-h-screen flex flex-col items-center justify-center p-4">
            <AppLogo />
            <Card className="w-full max-w-lg">
                <CardHeader className="text-center">
                    <CardTitle className="text-2xl">Complete seu Cadastro</CardTitle>
                    <CardDescription>
                        Olá, {user.full_name}! Para continuar, escolha seu tipo de conta.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
                        <button
                            onClick={() => setRole('student')}
                            className={`p-6 border-2 rounded-lg text-center transition-all ${
                                role === 'student' 
                                    ? 'border-orange-500 bg-orange-50' 
                                    : 'border-gray-200 hover:border-gray-400'
                            }`}
                        >
                            <UserIcon className="w-10 h-10 mx-auto mb-3 text-orange-600" />
                            <h3 className="font-semibold text-lg">Sou Aluno</h3>
                            <p className="text-sm text-gray-500">Quero receber treinos e dietas.</p>
                        </button>
                        
                        <button
                            onClick={() => setRole('trainer')}
                            className={`p-6 border-2 rounded-lg text-center transition-all ${
                                role === 'trainer' 
                                    ? 'border-blue-500 bg-blue-50' 
                                    : 'border-gray-200 hover:border-gray-400'
                            }`}
                        >
                            <Shield className="w-10 h-10 mx-auto mb-3 text-blue-600" />
                            <h3 className="font-semibold text-lg">Sou Personal</h3>
                            <p className="text-sm text-gray-500">Quero gerenciar meus alunos.</p>
                        </button>
                    </div>

                    {error && <p className="text-sm text-red-600 text-center mb-4">{error}</p>}
                    
                    <Button
                        onClick={handleSubmit}
                        disabled={isSaving || !role}
                        className="w-full bg-green-600 hover:bg-green-700 text-white py-3"
                    >
                        {isSaving ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Salvando...
                            </>
                        ) : (
                            'Confirmar e Continuar'
                        )}
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}

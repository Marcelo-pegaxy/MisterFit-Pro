
import React, { useState, useEffect } from 'react';
import { WorkoutPlan } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { PlusCircle, ListChecks, MoreHorizontal, Pencil, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import WorkoutForm from '@/components/workouts/WorkoutForm';

const WorkoutList = ({ plans, students, onEdit, onDelete }) => {
    const getStudentName = (email) => {
        if (!email) return "Não atribuído";
        const student = students.find(s => s.email === email);
        return student ? student.full_name : email; // Changed from 'name' to 'full_name'
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plans.map(plan => (
                <Card key={plan.id} className="hover:shadow-lg transition-shadow flex flex-col">
                    {plan.image_url && (
                        <img src={plan.image_url} alt={plan.name} className="w-full h-40 object-cover rounded-t-lg" />
                    )}
                    <CardHeader>
                        <div className="flex justify-between items-start">
                           <CardTitle>{plan.name}</CardTitle>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => onEdit(plan)}>
                                        <Pencil className="mr-2 h-4 w-4" />
                                        Editar
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => onDelete(plan.id)} className="text-red-600">
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Excluir
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                        <CardDescription>
                            Para: <Badge variant={plan.student_email ? "secondary" : "outline"}>
                                {getStudentName(plan.student_email)}
                            </Badge>
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-grow">
                        <p className="text-sm text-gray-600 line-clamp-2">{plan.description}</p>
                        <p className="text-sm text-gray-500 mt-2">{(plan.exercises || []).length} exercícios</p>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
};

const EmptyState = ({ onNewWorkout }) => (
    <Card>
        <div className="text-center py-16 px-4 flex flex-col items-center">
            <div className="p-4 bg-gray-100 rounded-full">
                <ListChecks className="w-12 h-12 text-gray-400" />
            </div>
            <h2 className="mt-6 text-xl font-semibold text-gray-800">Nenhum treino criado ainda</h2>
            <p className="mt-2 text-sm text-gray-500">Comece adicionando seu primeiro plano de treino.</p>
            <Button onClick={onNewWorkout} className="mt-6 bg-orange-500 hover:bg-orange-600 text-white">
                <PlusCircle className="mr-2 h-4 w-4" /> Criar Novo Treino
            </Button>
        </div>
    </Card>
);

export default function Workouts() {
    const [workoutPlans, setWorkoutPlans] = useState([]);
    const [students, setStudents] = useState([]);
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingWorkout, setEditingWorkout] = useState(null); // New state for editing

    const fetchData = async (currentUser) => {
        if (!currentUser) {
            setIsLoading(false); // Ensure loading state is reset if no user
            return;
        }
        setIsLoading(true);
        try {
            const [plans, studs] = await Promise.all([
                WorkoutPlan.filter({ trainer_email: currentUser.email }, '-created_date'),
                // Keeping original student filtering logic for consistency and security,
                // as outline's change to UserAccount.filter({ role: 'student' }) would
                // fetch all students and UserAccount is not defined.
                User.filter({ role: 'student', linked_trainer_email: currentUser.email }) 
            ]);
            setWorkoutPlans(plans);
            setStudents(studs);
        } catch (error) {
            console.error("Error fetching workout data:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const init = async () => {
            try {
                // Changed user loading from User.me() to localStorage as per outline
                const storedUser = localStorage.getItem('currentUser');
                if (storedUser) {
                  const currentUser = JSON.parse(storedUser);
                  setUser(currentUser);
                  await fetchData(currentUser);
                } else {
                    setIsLoading(false); // No user found, stop loading
                }
            } catch (e) {
                console.error("Error initializing workouts:", e);
                setIsLoading(false);
            }
        };
        init();
    }, []);
    
    const handleFormFinished = () => {
        setIsFormOpen(false);
        setEditingWorkout(null); // Clear editing state
        fetchData(user); // Re-fetch data after form submission
    };

    const handleNewWorkout = () => {
        setEditingWorkout(null); // Ensure no workout is being edited
        setIsFormOpen(true);
    };

    const handleEditWorkout = (workout) => {
        setEditingWorkout(workout);
        setIsFormOpen(true);
    };

    const handleDeleteWorkout = async (workoutId) => {
        if (window.confirm("Tem certeza que deseja excluir este treino? Esta ação não pode ser desfeita.")) {
            try {
                setIsLoading(true); // Show loading while deleting
                await WorkoutPlan.delete(workoutId);
                fetchData(user); // Re-fetch data to update list
            } catch (error) {
                console.error("Erro ao excluir treino:", error);
                setIsLoading(false); // Stop loading on error
            }
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-gray-800">Criar Treinos</h1>
                    <p className="text-gray-500">Elabore treinos personalizados para seus alunos.</p>
                </div>
                 <Button onClick={handleNewWorkout} className="bg-orange-500 hover:bg-orange-600 text-white">
                     <PlusCircle className="mr-2 h-4 w-4" /> Criar Novo Treino
                 </Button>
            </div>

            <div>
                {isLoading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-64 rounded-lg" />)}
                    </div>
                ) : workoutPlans.length > 0 ? (
                    <WorkoutList 
                        plans={workoutPlans} 
                        students={students} 
                        onEdit={handleEditWorkout} 
                        onDelete={handleDeleteWorkout} 
                    />
                ) : (
                    <EmptyState onNewWorkout={handleNewWorkout} />
                )}
            </div>

            <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
                <DialogContent className="max-w-3xl">
                     <DialogHeader>
                        <DialogTitle>{editingWorkout ? 'Editar Treino' : 'Criar Novo Treino'}</DialogTitle>
                        <DialogDescription>
                           {editingWorkout ? 'Altere os detalhes do treino abaixo.' : 'Preencha os detalhes do novo treino.'}
                        </DialogDescription>
                    </DialogHeader>
                    <WorkoutForm 
                        user={user} 
                        students={students} 
                        onFinished={handleFormFinished} 
                        existingWorkout={editingWorkout} // Pass existing workout for editing
                    />
                </DialogContent>
            </Dialog>
        </div>
    );
}

import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dumbbell, Users, MessageSquare, TrendingUp } from 'lucide-react';
import { User } from '@/api/entities';
import { createPageUrl } from '@/utils';

const AppLogo = ({ className }) => (
    <div className={`flex items-center justify-center gap-3 ${className}`}>
        <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ee7cadce2_novologo.png" 
            alt="MisterFit Logo" 
            className="w-12 h-12 object-contain"
        />
        <h1 className="text-4xl font-bold text-white">MisterFit</h1>
    </div>
);

const FeatureCard = ({ icon: Icon, title, description }) => (
    <Card className="text-center shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 bg-white">
        <CardHeader>
            <div className="mx-auto bg-blue-100 rounded-full p-3 w-fit">
                <Icon className="w-8 h-8 text-blue-600" />
            </div>
        </CardHeader>
        <CardContent>
            <CardTitle className="text-lg font-semibold text-gray-800 mb-2">{title}</CardTitle>
            <p className="text-sm text-gray-600">{description}</p>
        </CardContent>
    </Card>
);

export default function LandingPage() {
    const [debugInfo, setDebugInfo] = useState('');
    
    useEffect(() => {
        // Verificação imediata ao carregar a página
        const checkCurrentUser = async () => {
            try {
                const currentUser = await User.me();
                const debugMsg = `🔍 USUÁRIO ENCONTRADO NA LANDING:\n` +
                    `Email: ${currentUser.email}\n` +
                    `Role: ${currentUser.role}\n` +
                    `ID: ${currentUser.id}\n` +
                    `Created: ${currentUser.created_date}\n` +
                    `Objeto completo: ${JSON.stringify(currentUser, null, 2)}`;
                
                console.log(debugMsg);
                setDebugInfo(debugMsg);
                
                // Se tem usuário, algo está errado - não deveria estar na Landing
                alert('PROBLEMA DETECTADO! Usuário já existe mas está na Landing Page. Veja o console.');
                
            } catch (error) {
                console.log('✅ OK: Nenhum usuário logado encontrado na Landing (como esperado)');
                setDebugInfo('✅ OK: Nenhum usuário logado (como esperado)');
            }
        };
        
        checkCurrentUser();
    }, []);

    const handleLogin = async () => {
        try {
            console.log('🚀 INICIANDO LOGIN...');
            setDebugInfo('🚀 Iniciando login...');
            
            await User.login();
            
            // Após o login, verificar o usuário criado
            setTimeout(async () => {
                try {
                    const userAfterLogin = await User.me();
                    const postLoginMsg = `🔍 USUÁRIO APÓS LOGIN:\n` +
                        `Email: ${userAfterLogin.email}\n` +
                        `Role: ${userAfterLogin.role}\n` +
                        `ID: ${userAfterLogin.id}\n` +
                        `Created: ${userAfterLogin.created_date}\n` +
                        `Objeto completo: ${JSON.stringify(userAfterLogin, null, 2)}`;
                    
                    console.log(postLoginMsg);
                    setDebugInfo(postLoginMsg);
                    
                    alert('LOGIN REALIZADO! Veja o console para detalhes do usuário criado.');
                } catch (e) {
                    console.log('Erro ao verificar usuário pós-login:', e);
                }
            }, 2000);
            
        } catch (error) {
            console.error("Erro no processo de login:", error);
            setDebugInfo(`❌ Erro no login: ${error.message}`);
        }
    };

    return (
        <div className="w-full bg-gray-50">
            {/* Debug Info */}
            {debugInfo && (
                <div className="bg-yellow-100 border border-yellow-400 p-4 m-4 rounded">
                    <h3 className="font-bold">🐛 DEBUG INFO:</h3>
                    <pre className="text-xs mt-2 whitespace-pre-wrap">{debugInfo}</pre>
                </div>
            )}

            {/* Hero Section */}
            <section className="bg-gradient-to-br from-orange-600 via-orange-500 to-yellow-500 py-20 px-4">
                <div className="max-w-6xl mx-auto text-center">
                    <AppLogo className="mb-8" />
                    <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">
                        A plataforma completa para Personal Trainers e Alunos
                    </h2>
                    <p className="text-lg text-orange-100 mb-8 max-w-2xl mx-auto">
                        Gerencie treinos, dietas, avaliações e mantenha contato direto com seus alunos. 
                        Tudo em um só lugar, de forma simples e profissional.
                    </p>
                    <Button 
                        onClick={handleLogin}
                        size="lg" 
                        className="bg-white text-orange-600 hover:bg-gray-100 font-semibold px-8 py-3 text-lg"
                    >
                        Entrar na Plataforma
                    </Button>
                </div>
            </section>

            {/* Features Section */}
            <section className="py-16 px-4">
                <div className="max-w-6xl mx-auto">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl font-bold text-gray-800 mb-4">
                            Tudo que você precisa em uma plataforma
                        </h2>
                        <p className="text-gray-600 text-lg">
                            Ferramentas profissionais para elevar seu trabalho a outro nível
                        </p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        <FeatureCard 
                            icon={Dumbbell}
                            title="Treinos Personalizados"
                            description="Crie e gerencie planos de treino únicos para cada aluno"
                        />
                        <FeatureCard 
                            icon={Users}
                            title="Gestão de Alunos"
                            description="Acompanhe o progresso e histórico completo de cada pessoa"
                        />
                        <FeatureCard 
                            icon={MessageSquare}
                            title="Chat Integrado"
                            description="Comunicação direta e rápida com seus alunos"
                        />
                        <FeatureCard 
                            icon={TrendingUp}
                            title="Relatórios Detalhados"
                            description="Acompanhe resultados e evolução com dados precisos"
                        />
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="bg-gray-800 py-16 px-4">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-3xl font-bold text-white mb-4">
                        Pronto para transformar seu trabalho?
                    </h2>
                    <p className="text-gray-300 text-lg mb-8">
                        Junte-se a centenas de profissionais que já utilizam o MisterFit
                    </p>
                    <Button 
                        onClick={handleLogin}
                        size="lg" 
                        className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-3 text-lg"
                    >
                        Começar Agora - É Grátis
                    </Button>
                </div>
            </section>

            {/* Footer */}
            <footer className="bg-gray-900 py-8 px-4">
                <div className="max-w-6xl mx-auto text-center">
                    <div className="flex items-center justify-center gap-3 mb-4">
                        <img 
                            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ee7cadce2_novologo.png" 
                            alt="MisterFit Logo" 
                            className="w-8 h-8 object-contain"
                        />
                        <span className="text-white font-bold text-lg">MisterFit</span>
                    </div>
                    <p className="text-gray-400 text-sm">
                        © 2024 MisterFit. Transformando a relação entre Personal Trainers e Alunos.
                    </p>
                </div>
            </footer>
        </div>
    );
}
import React from 'react';
export default function Financial() {
    return <div className="text-center p-8"><h1 className="text-2xl font-bold">Financeiro</h1><p>Esta página está em construção.</p></div>;
}
import React from 'react';
export default function Settings() {
    return <div className="text-center p-8"><h1 className="text-2xl font-bold">Configurações</h1><p>Esta página está em construção.</p></div>;
}
import React, { useState, useEffect } from 'react';
import { UserAccount } from '@/api/entities/UserAccount';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Users } from 'lucide-react';

export default function TestUsers() {
    const [users, setUsers] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const allUsers = await UserAccount.list();
                console.log('Todos os usuários:', allUsers);
                setUsers(allUsers);
            } catch (error) {
                console.error('Erro ao buscar usuários:', error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchUsers();
    }, []);

    return (
        <div className="bg-gray-50 min-h-screen p-4">
            <div className="max-w-4xl mx-auto">
                <div className="mb-6">
                    <Link to={createPageUrl('Register')} className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4">
                        <ArrowLeft className="w-4 h-4" />
                        Voltar ao Login
                    </Link>
                    <h1 className="text-2xl font-bold text-gray-800">Usuários Cadastrados (Debug)</h1>
                    <p className="text-gray-500">Lista de todos os usuários no sistema para debug.</p>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Users className="w-5 h-5" />
                            Total: {users.length} usuários
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isLoading ? (
                            <p>Carregando usuários...</p>
                        ) : users.length > 0 ? (
                            <div className="space-y-4">
                                {users.map((user, index) => (
                                    <div key={user.id || index} className="border rounded-lg p-4 bg-gray-50">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                                            <p><strong>Nome:</strong> {user.full_name}</p>
                                            <p><strong>Email:</strong> {user.email}</p>
                                            <p><strong>Role:</strong> {user.role}</p>
                                            <p><strong>Ativo:</strong> {user.is_active ? 'Sim' : 'Não'}</p>
                                            {user.unique_share_id && (
                                                <p><strong>ID Share:</strong> {user.unique_share_id}</p>
                                            )}
                                            <p><strong>Criado em:</strong> {new Date(user.created_date).toLocaleString()}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-500">Nenhum usuário encontrado no sistema.</p>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
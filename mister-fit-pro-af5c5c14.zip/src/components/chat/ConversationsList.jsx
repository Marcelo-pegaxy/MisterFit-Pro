
import React, { useState, useEffect } from 'react';
import { ChatMessage } from '@/api/entities';
import { User } from '@/api/entities'; // Changed from UserAccount to User
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function ConversationsList({ currentUser, onSelectConversation, selectedConversation }) {
    const [conversations, setConversations] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    const loadConversations = async () => {
        if (!currentUser) return; // Added check for currentUser
        setIsLoading(true);
        try {
            // Buscar pessoas vinculadas baseado no role
            let contacts = [];
            const allUsers = await User.list(); // Changed from UserAccount.list() to User.list()
            
            if (currentUser.role === 'trainer' || currentUser.role === 'admin') { // Added admin role
                // Personal vê seus alunos
                // Admin vê todos os alunos
                contacts = allUsers.filter(user => 
                    user.role === 'student' && 
                    (currentUser.role === 'admin' || user.linked_trainer_email === currentUser.email) // Logic for admin vs trainer
                );
            } else if (currentUser.role === 'student' && currentUser.linked_trainer_email) {
                // Aluno vê seu personal
                contacts = allUsers.filter(user => 
                    user.email === currentUser.linked_trainer_email 
                    // The original code had `user.role === 'trainer'` here,
                    // but the outline suggests removing it by only keeping `user.email === currentUser.linked_trainer_email`.
                    // Following the outline, so removing the role check here.
                );
            }

            // Para cada contato, buscar a última mensagem
            const conversationsData = await Promise.all(
                contacts.map(async (contact) => {
                    const conversationId = `${[currentUser.email, contact.email].sort().join('_')}`;
                    
                    const lastMessages = await ChatMessage.filter(
                        { conversation_id: conversationId },
                        '-created_date',
                        1
                    );

                    const unreadMessages = await ChatMessage.filter({
                        conversation_id: conversationId,
                        receiver_email: currentUser.email,
                        is_read: false
                    });

                    return {
                        ...contact,
                        lastMessage: lastMessages[0] || null,
                        unreadCount: unreadMessages.length
                    };
                })
            );

            // Ordenar por última mensagem
            conversationsData.sort((a, b) => {
                if (!a.lastMessage && !b.lastMessage) return 0;
                if (!a.lastMessage) return 1;
                if (!b.lastMessage) return -1;
                return new Date(b.lastMessage.created_date) - new Date(a.lastMessage.created_date);
            });

            setConversations(conversationsData);
        } catch (error) {
            console.error("Erro ao carregar conversas:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadConversations();
        const interval = setInterval(loadConversations, 5000); // Atualizar a cada 5 segundos
        return () => clearInterval(interval);
    }, [currentUser]);

    if (isLoading) {
        return (
            <div className="space-y-2">
                {Array(3).fill(0).map((_, i) => (
                    <div key={i} className="animate-pulse">
                        <Card><CardContent className="p-4 h-16 bg-gray-100"></CardContent></Card>
                    </div>
                ))}
            </div>
        );
    }

    if (conversations.length === 0) {
        return (
            <Card>
                <CardContent className="p-8 text-center">
                    <p className="text-gray-500">
                        {currentUser.role === 'trainer' 
                            ? 'Nenhum aluno vinculado ainda.'
                            : currentUser.role === 'admin'
                                ? 'Nenhum aluno encontrado no sistema.'
                                : 'Você não está vinculado a nenhum personal trainer.'
                        }
                    </p>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-2">
            {conversations.map((conversation) => (
                <Card 
                    key={conversation.id} 
                    className={`cursor-pointer transition-colors hover:bg-gray-50 ${
                        selectedConversation?.id === conversation.id ? 'ring-2 ring-orange-500' : ''
                    }`}
                    onClick={() => onSelectConversation(conversation)}
                >
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Avatar>
                                <AvatarFallback className="bg-orange-100 text-orange-600">
                                    {conversation.full_name?.[0]?.toUpperCase()}
                                </AvatarFallback>
                            </Avatar>
                            
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start">
                                    <h3 className="font-semibold text-gray-800 truncate">
                                        {conversation.full_name}
                                    </h3>
                                    <div className="flex items-center gap-2">
                                        {conversation.unreadCount > 0 && (
                                            <Badge variant="destructive" className="text-xs">
                                                {conversation.unreadCount}
                                            </Badge>
                                        )}
                                        {conversation.lastMessage && (
                                            <span className="text-xs text-gray-500">
                                                {formatDistanceToNow(new Date(conversation.lastMessage.created_date), { addSuffix: true, locale: ptBR })}
                                            </span>
                                        )}
                                    </div>
                                </div>
                                
                                <p className="text-sm text-gray-500 capitalize mb-1">
                                    {conversation.role === 'trainer' ? 'Personal Trainer' : 
                                     conversation.role === 'student' ? 'Aluno' : 
                                     conversation.role}
                                </p>
                                
                                {conversation.lastMessage && (
                                    <p className="text-sm text-gray-600 truncate">
                                        {conversation.lastMessage.sender_email === currentUser.email ? 'Você: ' : ''}
                                        {conversation.lastMessage.message_type === 'image' ? '📷 Imagem' : 
                                         conversation.lastMessage.message_type === 'file' ? '📎 Arquivo' : 
                                         conversation.lastMessage.message}
                                    </p>
                                )}
                            </div>
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}

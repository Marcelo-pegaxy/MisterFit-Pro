import React, { useState, useEffect } from 'react';
import { StudentFinancials } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, CalendarIcon, Receipt, Copy, CheckCircle } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';

const GenerateInvoiceDialog = ({ student, financials, onInvoiceGenerated }) => {
    const [invoiceData, setInvoiceData] = useState({
        amount: financials?.amount || '',
        description: `Mensalidade Personal Training - ${new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}`,
        due_date: financials?.next_due_date ? new Date(financials.next_due_date) : new Date(),
    });
    const [generatedInvoice, setGeneratedInvoice] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [copied, setCopied] = useState(false);

    const generateInvoice = () => {
        setIsGenerating(true);
        
        // Simular geração de cobrança
        setTimeout(() => {
            const invoiceId = `INV-${Date.now()}`;
            const pixCode = `00020126580014BR.GOV.BCB.PIX0136${student.email}5204000053039865802BR5925${student.full_name}6009SAO PAULO62070503***6304`;
            
            const invoice = {
                id: invoiceId,
                student_name: student.full_name,
                student_email: student.email,
                amount: parseFloat(invoiceData.amount),
                description: invoiceData.description,
                due_date: format(invoiceData.due_date, 'dd/MM/yyyy'),
                pix_code: pixCode,
                payment_link: `https://misterfit.com/pay/${invoiceId}`,
                status: 'pendente'
            };
            
            setGeneratedInvoice(invoice);
            setIsGenerating(false);
        }, 2000);
    };

    const copyToClipboard = (text, type) => {
        navigator.clipboard.writeText(text);
        setCopied(type);
        setTimeout(() => setCopied(false), 2000);
    };

    const sendInvoiceToStudent = () => {
        // Aqui seria integrado com um sistema de email real
        alert(`Cobrança enviada por email para ${student.email}!`);
        onInvoiceGenerated();
    };

    return (
        <DialogContent className="max-w-2xl">
            <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                    <Receipt className="w-5 h-5" />
                    Gerar Cobrança para {student.full_name}
                </DialogTitle>
                <DialogDescription>
                    Configure os detalhes da cobrança que será enviada ao aluno.
                </DialogDescription>
            </DialogHeader>

            {!generatedInvoice ? (
                <div className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <Label htmlFor="amount">Valor (R$)</Label>
                            <Input
                                id="amount"
                                type="number"
                                step="0.01"
                                value={invoiceData.amount}
                                onChange={(e) => setInvoiceData({...invoiceData, amount: e.target.value})}
                                placeholder="0,00"
                            />
                        </div>
                        <div>
                            <Label>Data de Vencimento</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {format(invoiceData.due_date, 'dd/MM/yyyy')}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                    <Calendar
                                        mode="single"
                                        selected={invoiceData.due_date}
                                        onSelect={(date) => setInvoiceData({...invoiceData, due_date: date})}
                                        initialFocus
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>
                    </div>
                    
                    <div>
                        <Label htmlFor="description">Descrição da Cobrança</Label>
                        <Input
                            id="description"
                            value={invoiceData.description}
                            onChange={(e) => setInvoiceData({...invoiceData, description: e.target.value})}
                            placeholder="Ex: Mensalidade Personal Training"
                        />
                    </div>

                    <DialogFooter>
                        <Button 
                            onClick={generateInvoice}
                            disabled={isGenerating || !invoiceData.amount}
                            className="bg-green-600 hover:bg-green-700 text-white"
                        >
                            {isGenerating ? 'Gerando...' : 'Gerar Cobrança'}
                        </Button>
                    </DialogFooter>
                </div>
            ) : (
                <div className="space-y-4 py-4">
                    <Alert className="bg-green-50 border-green-200">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <AlertTitle className="text-green-800">Cobrança Gerada com Sucesso!</AlertTitle>
                        <AlertDescription className="text-green-700">
                            A cobrança foi criada e está pronta para ser enviada ao aluno.
                        </AlertDescription>
                    </Alert>

                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Detalhes da Cobrança</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4 text-sm">
                                <div><strong>ID:</strong> {generatedInvoice.id}</div>
                                <div><strong>Valor:</strong> R$ {generatedInvoice.amount.toFixed(2)}</div>
                                <div><strong>Vencimento:</strong> {generatedInvoice.due_date}</div>
                                <div><strong>Status:</strong> <span className="text-yellow-600">Pendente</span></div>
                            </div>
                            
                            <div>
                                <strong>Descrição:</strong>
                                <p className="text-gray-600">{generatedInvoice.description}</p>
                            </div>

                            <div className="space-y-2">
                                <Label>Link de Pagamento</Label>
                                <div className="flex items-center gap-2">
                                    <Input value={generatedInvoice.payment_link} readOnly className="flex-1" />
                                    <Button 
                                        size="sm" 
                                        variant="outline" 
                                        onClick={() => copyToClipboard(generatedInvoice.payment_link, 'link')}
                                    >
                                        {copied === 'link' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                    </Button>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label>Código PIX</Label>
                                <div className="flex items-center gap-2">
                                    <Input value={generatedInvoice.pix_code} readOnly className="flex-1 text-xs" />
                                    <Button 
                                        size="sm" 
                                        variant="outline" 
                                        onClick={() => copyToClipboard(generatedInvoice.pix_code, 'pix')}
                                    >
                                        {copied === 'pix' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <DialogFooter className="gap-2">
                        <Button variant="outline" onClick={() => setGeneratedInvoice(null)}>
                            Gerar Nova Cobrança
                        </Button>
                        <Button 
                            onClick={sendInvoiceToStudent}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                        >
                            Enviar por Email
                        </Button>
                    </DialogFooter>
                </div>
            )}
        </DialogContent>
    );
};

export default function FinancialsTab({ student, trainer, onUpdate }) {
    const [financials, setFinancials] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [isInvoiceDialogOpen, setIsInvoiceDialogOpen] = useState(false);
    const [formData, setFormData] = useState({
        amount: '',
        payment_period: 'mensal',
        next_due_date: new Date(),
    });

    const fetchFinancials = async () => {
        setIsLoading(true);
        try {
            const data = await StudentFinancials.filter({ student_email: student.email, trainer_email: trainer.email });
            if (data.length > 0) {
                const finData = data[0];
                 // Verifica se a data de vencimento passou
                const isOverdue = new Date(finData.next_due_date) < new Date() && finData.status !== 'pago';
                if (isOverdue && finData.status !== 'atrasado') {
                    // Atualiza o status para 'atrasado'
                    const updated = await StudentFinancials.update(finData.id, { status: 'atrasado' });
                    setFinancials(updated);
                } else {
                    setFinancials(finData);
                }

                setFormData({
                    amount: finData.amount,
                    payment_period: finData.payment_period,
                    next_due_date: new Date(finData.next_due_date)
                });
            } else {
                setFinancials(null);
                setIsEditing(true); // Se não tem dados, já abre o form de criação
            }
        } catch (error) {
            console.error("Erro ao buscar dados financeiros:", error);
        }
        setIsLoading(false);
    };

    useEffect(() => {
        fetchFinancials();
    }, [student, trainer]);

    const handleSave = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        const dataToSave = {
            ...formData,
            student_email: student.email,
            trainer_email: trainer.email,
            next_due_date: format(formData.next_due_date, 'yyyy-MM-dd'),
            status: 'em_dia'
        };

        try {
            if (financials) {
                await StudentFinancials.update(financials.id, dataToSave);
            } else {
                await StudentFinancials.create(dataToSave);
            }
            await fetchFinancials(); // Re-fetch to get latest data
            setIsEditing(false);
            if(onUpdate) onUpdate();
        } catch (error) {
            console.error("Erro ao salvar dados financeiros:", error);
        }
        setIsLoading(false);
    };

    const handleMarkAsPaid = async () => {
        if (!financials) return;
        setIsLoading(true);
        try {
            let nextDueDate;
            const currentDueDate = new Date(financials.next_due_date);
            switch(financials.payment_period) {
                case 'mensal':
                    nextDueDate = new Date(currentDueDate.setMonth(currentDueDate.getMonth() + 1));
                    break;
                case 'trimestral':
                    nextDueDate = new Date(currentDueDate.setMonth(currentDueDate.getMonth() + 3));
                    break;
                case 'semestral':
                     nextDueDate = new Date(currentDueDate.setMonth(currentDueDate.getMonth() + 6));
                    break;
                case 'anual':
                     nextDueDate = new Date(currentDueDate.setFullYear(currentDueDate.getFullYear() + 1));
                    break;
                default:
                    nextDueDate = currentDueDate;
            }
            await StudentFinancials.update(financials.id, {
                status: 'em_dia', // reseta para 'em dia'
                next_due_date: format(nextDueDate, 'yyyy-MM-dd')
            });
            await fetchFinancials();
            if(onUpdate) onUpdate();
        } catch(error) {
            console.error("Erro ao marcar como pago:", error);
        }
        setIsLoading(false);
    };

    const handleInvoiceGenerated = () => {
        setIsInvoiceDialogOpen(false);
        // Aqui você pode adicionar lógica adicional como atualizar estatísticas
    };

    if (isLoading) {
        return <Skeleton className="h-48 w-full" />;
    }

    if (!financials && !isEditing) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>Dados Financeiros</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                    <p className="text-gray-500 mb-4">Nenhum plano financeiro cadastrado para este aluno.</p>
                    <Button onClick={() => setIsEditing(true)}>Configurar Plano</Button>
                </CardContent>
            </Card>
        );
    }
    
    if (!isEditing && financials) {
        return (
            <Card>
                {financials.status === 'atrasado' && (
                     <Alert variant="destructive" className="m-4">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Pagamento Atrasado!</AlertTitle>
                        <AlertDescription>
                            O vencimento era em {format(new Date(financials.next_due_date), 'dd/MM/yyyy')}.
                        </AlertDescription>
                    </Alert>
                )}
                <CardHeader>
                    <CardTitle>Plano Financeiro</CardTitle>
                    <CardDescription>Resumo do plano de pagamento do aluno.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div><strong className="block text-gray-500">Valor</strong> R$ {financials.amount.toFixed(2)}</div>
                        <div><strong className="block text-gray-500">Período</strong> <span className="capitalize">{financials.payment_period}</span></div>
                        <div><strong className="block text-gray-500">Próximo Vencimento</strong> {format(new Date(financials.next_due_date), 'dd/MM/yyyy')}</div>
                    </div>
                     <div className="flex gap-2 pt-4 border-t flex-wrap">
                        <Button onClick={() => setIsEditing(true)}>Editar Plano</Button>
                        <Button onClick={handleMarkAsPaid} variant="secondary">Marcar como Pago</Button>
                        <Dialog open={isInvoiceDialogOpen} onOpenChange={setIsInvoiceDialogOpen}>
                            <DialogTrigger asChild>
                                <Button className="bg-green-600 hover:bg-green-700 text-white">
                                    <Receipt className="w-4 h-4 mr-2" />
                                    Gerar Cobrança
                                </Button>
                            </DialogTrigger>
                            <GenerateInvoiceDialog 
                                student={student} 
                                financials={financials} 
                                onInvoiceGenerated={handleInvoiceGenerated}
                            />
                        </Dialog>
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>{financials ? 'Editar' : 'Configurar'} Plano Financeiro</CardTitle>
                <CardDescription>Defina os detalhes de pagamento para este aluno.</CardDescription>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSave} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <Label htmlFor="amount">Valor (R$)</Label>
                            <Input id="amount" type="number" step="0.01" value={formData.amount} onChange={(e) => setFormData({...formData, amount: e.target.value})} required/>
                        </div>
                        <div>
                            <Label htmlFor="payment_period">Período de Pagamento</Label>
                            <Select value={formData.payment_period} onValueChange={(v) => setFormData({...formData, payment_period: v})}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="mensal">Mensal</SelectItem>
                                    <SelectItem value="trimestral">Trimestral</SelectItem>
                                    <SelectItem value="semestral">Semestral</SelectItem>
                                    <SelectItem value="anual">Anual</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                     <div>
                        <Label>Data do Próximo Vencimento</Label>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {formData.next_due_date ? format(formData.next_due_date, "PPP", { locale: ptBR }) : <span>Escolha uma data</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={formData.next_due_date} onSelect={(d) => setFormData({...formData, next_due_date: d})} initialFocus /></PopoverContent>
                        </Popover>
                    </div>
                     <div className="flex justify-end gap-2 pt-4">
                        {financials && <Button type="button" variant="ghost" onClick={() => setIsEditing(false)}>Cancelar</Button>}
                        <Button type="submit" disabled={isLoading} className="bg-orange-500 text-white hover:bg-orange-600">
                           {isLoading ? 'Salvando...' : 'Salvar Plano'}
                        </Button>
                    </div>
                </form>
            </CardContent>
        </Card>
    );
}
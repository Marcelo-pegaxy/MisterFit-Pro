import { base44 } from './base44Client';


export const WorkoutPlan = base44.entities.WorkoutPlan;

export const DietPlan = base44.entities.DietPlan;

export const ChatMessage = base44.entities.ChatMessage;

export const Assessment = base44.entities.Assessment;

export const RecentActivity = base44.entities.RecentActivity;

export const StudentFinancials = base44.entities.StudentFinancials;

export const Payment = base44.entities.Payment;



// auth sdk:
export const User = base44.auth;